import { isLoggedIn } from 'beachtv-web/helpers/is-logged-in';
import { module, test } from 'qunit';

module('Unit | Helper | is logged in');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = isLoggedIn([42]);
  assert.ok(result);
});
