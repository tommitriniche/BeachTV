import { formatMoney } from 'beachtv-web/helpers/format-money';
import { module, test } from 'qunit';

module('Unit | Helper | format money');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = formatMoney([42]);
  assert.ok(result);
});
