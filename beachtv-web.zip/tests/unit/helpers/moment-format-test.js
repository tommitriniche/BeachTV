import { momentFormat } from 'beachtv-web/helpers/moment-format';
import { module, test } from 'qunit';

module('Unit | Helper | moment format');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = momentFormat([42]);
  assert.ok(result);
});
