import { numberFormat } from 'beachtv-web/helpers/number-format';
import { module, test } from 'qunit';

module('Unit | Helper | number format');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = numberFormat([42]);
  assert.ok(result);
});
