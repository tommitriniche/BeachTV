import { styleUrlBgCover } from 'beachtv-web/helpers/style-url-bg-cover';
import { module, test } from 'qunit';

module('Unit | Helper | style url bg cover');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = styleUrlBgCover([42]);
  assert.ok(result);
});
