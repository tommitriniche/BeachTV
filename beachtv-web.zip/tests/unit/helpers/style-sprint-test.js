import { styleSprint } from 'beachtv-web/helpers/style-sprint';
import { module, test } from 'qunit';

module('Unit | Helper | style sprint');

// Replace this with your real tests.
test('it works', function(assert) {
  let result = styleSprint([42]);
  assert.ok(result);
});
