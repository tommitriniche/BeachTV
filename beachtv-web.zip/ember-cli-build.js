/*jshint node:true*/
/* global require, module */
var EmberApp = require('ember-cli/lib/broccoli/ember-app');
var Funnel = require('broccoli-funnel');
var MergeTrees = require('broccoli-merge-trees');

module.exports = function(defaults) {
  var app = new EmberApp(defaults, {
    // Add options here
  });

  // CSS
  app.import('vendor/beagle/css/style.css');
  app.import('bower_components/vex/dist/css/vex.css');
  app.import('bower_components/vex/dist/css/vex-theme-os.css');
  app.import('bower_components/animate.css/animate.min.css');
  app.import('bower_components/fineuploader-dist/dist/fine-uploader.min.css');
  app.import('bower_components/mdi/css/materialdesignicons.min.css');
  app.import('vendor/beagle/lib/perfect-scrollbar/css/perfect-scrollbar.min.css');
  app.import('bower_components/bootstrap-daterangepicker/daterangepicker.css');
  app.import('bower_components/slick-carousel/slick/slick.css');
  app.import('bower_components/slick-carousel/slick/slick-theme.css');
  app.import('bower_components/video.js/dist/video-js.min.css');
  app.import('bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker3.min.css');
  app.import('bower_components/intl-tel-input/build/css/intlTelInput.css');
  
  // Fonts
  var mdiFonts = new Funnel('bower_components/mdi/fonts', {destDir: 'fonts'});
  var slickFonts = new Funnel('bower_components/slick-carousel/slick/fonts', {destDir: 'assets/fonts'});
  var robotoFonts = new Funnel('vendor/beagle/lib/roboto', {destDir: 'lib/roboto'});
  
  // FineUploader Images
  app.import('bower_components/fineuploader-dist/dist/edit.gif', { destDir: 'assets' });
  app.import('bower_components/fineuploader-dist/dist/loading.gif', { destDir: 'assets' });
  app.import('bower_components/fineuploader-dist/dist/pause.gif', { destDir: 'assets' });
  app.import('bower_components/fineuploader-dist/dist/processing.gif', { destDir: 'assets' });
  app.import('bower_components/fineuploader-dist/dist/retry.gif', { destDir: 'assets' });
  app.import('bower_components/fineuploader-dist/dist/continue.gif', { destDir: 'assets' });
  app.import('bower_components/fineuploader-dist/dist/trash.gif', { destDir: 'assets' });
  
  // Intl Input Images
  app.import('bower_components/intl-tel-input/build/img/flags.png', {destDir: 'img'});
  app.import('bower_components/intl-tel-input/build/img/flags@2x.png', {destDir: 'img'});
  
  // Javascript
  app.import('bower_components/jquery-ui/jquery-ui.min.js');
  app.import('bower_components/bootstrap/dist/js/bootstrap.min.js');
  app.import('bower_components/materialize/dist/js/materialize.min.js');
  app.import('bower_components/moment/min/moment.min.js');
  app.import('bower_components/numeral/min/numeral.min.js');
  app.import('bower_components/underscore/underscore-min.js');
  app.import('bower_components/vex/dist/js/vex.combined.min.js');
  app.import('bower_components/blueimp-md5/js/md5.min.js');
  app.import('bower_components/cookies-js/dist/cookies.min.js');
  app.import('bower_components/jquery.inputmask/dist/jquery.inputmask.bundle.js');
  app.import('bower_components/jquery.maskedinput/dist/jquery.maskedinput.min.js');
  app.import('bower_components/jquery-slimscroll/jquery.slimscroll.min.js');
  app.import('bower_components/fineuploader-dist/dist/s3.jquery.fine-uploader.min.js');
  app.import('vendor/beagle/lib/perfect-scrollbar/js/perfect-scrollbar.jquery.min.js');
  app.import('vendor/beagle/lib/jquery.niftymodals/dist/jquery.niftymodals.js');
  app.import('bower_components/bootstrap-daterangepicker/daterangepicker.js');
  app.import('bower_components/slick-carousel/slick/slick.min.js');
  app.import('bower_components/video.js/dist/video.min.js');
  app.import('bower_components/video.js/dist/ie8/videojs-ie8.min.js');
  app.import('bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js');
  app.import('bower_components/intl-tel-input/build/js/intlTelInput.min.js');
  app.import('bower_components/intl-tel-input/build/js/utils.js', {destDir: 'intl'});
  app.import('bower_components/sprintf/dist/sprintf.min.js');
  app.import('bower_components/slideout.js/dist/slideout.min.js');
  app.import('bower_components/vide/dist/jquery.vide.min.js');
  
  return app.toTree(new MergeTrees([mdiFonts, robotoFonts, slickFonts], {overwrite: true}));
};
