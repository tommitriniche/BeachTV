fuser -n tcp -k 5566
