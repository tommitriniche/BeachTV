import Ember from 'ember';

export default Ember.Controller.extend({
    actions: {
        prepareComment: function() {
            // do stuff
            this.set('newCommentFocus', true);
        },
        
        cancelComment: function() {
            this.set('newCommentFocus', false);
            this.resetComment();
        },
        
        postComment: function() {
            var comment = this.get('newComment');
            if(comment.get('content.length') > 0) {
                comment.save().then(function() {
                    this.resetComment();
                    this.send('reload');
                }.bind(this));
            }
        }
    },
    
    newCommentFocus: false,
    
    resetComment: function() {
        this.set('newComment', this.store.createRecord('comment', {
            user_uuid: Cookies.get('userSession'),
            content: null,
            object_uuid: this.get('model.video.id'),
            object_type: 'video',
            order: 0,
            views: 0,
            notify_owner_replies: false
        }));
    },
    
    newComment: function() {
        return this.store.createRecord('comment', {
            user_uuid: Cookies.get('userSession'),
            content: null,
            object_uuid: this.get('model.video.id'),
            object_type: 'video',
            order: 0,
            views: 0,
            notify_owner_replies: false
        });
    }.property('comment')
});
