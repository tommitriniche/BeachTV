import Ember from 'ember';

export default Ember.Controller.extend({
    isMobile: function() {
        return window.isMobile;
    }.property()
});
