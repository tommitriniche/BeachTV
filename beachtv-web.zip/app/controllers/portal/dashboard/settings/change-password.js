import Ember from 'ember';

export default Ember.Controller.extend({
    
    actions: {
        /**
         * saves the system user
         * @return null
         */
        saveUser: function() {
            var controller = this;
            var user = this.get('user');
            user.save().then(function() {
                controller.get('notifications').success('Password updated!');
            }.bind(this), function(errorResponse) {
                return controller.get('notifications').error(errorResponse.errors[0].detail);
            });
        }
    },
    
    /**
     * get the current user using app
     * @return DS.Model
     */
    user: function() {
        return this.store.peekRecord('user', Cookies.get('userSession'));
    }.property('user'),

});
