import Ember from 'ember';

export default Ember.Controller.extend({
    
    actions: {
        /**
         * saves the system user
         * @return null
         */
        saveUser: function() {
            var controller = this;
            var user = this.get('user');
            user.save().then(function() {
                controller.get('notifications').success('Account settings saved!');
            }.bind(this), function(errorResponse) {
                return controller.get('notifications').error(errorResponse.errors[0].detail);
            });
        }
    },
    
    /**
     * get the current user using app
     * @return DS.Model
     */
    user: function() {
        return this.store.peekRecord('user', Cookies.get('userSession'));
    }.property('user'),
    
    /**
     * the image uploaded
     * @return array
     */
    upload: null,
    
    /**
     * Handle file uploads by saving them to a temp array to be fixed with the 
     * event id as the key upon saving the event
     */
    handleUpload: function() {
        var upload = this.get('upload');
        this.set('user.avatar_uuid', upload.uuid);
    }.observes('upload'),
});
