import Ember from 'ember';

export default Ember.Controller.extend({
    hasSeries: function() {
        console.log(this.get('model.series.length'));
        return (this.get('model.series.length') || this.get('model.series_categories.length'));
    }.property('model.series.[]', 'model.series_categories.[]')
});
