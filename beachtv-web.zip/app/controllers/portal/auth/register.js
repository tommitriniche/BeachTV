import Ember from 'ember';

export default Ember.Controller.extend({
    actions: {
        register: function() {
            var user = this.get('user');
            if(!this.get('user.first_name')) {
                return this.get('notifications').error('First name field cannot be empty.');
            }
            if(!this.get('user.last_name')) {
                return this.get('notifications').error('Last name field cannot be empty.');
            }
            if(!this.get('user.email')) {
                return this.get('notifications').error('Your email address is required to continue.');
            }
            if(!this.validateEmail(this.get('user.email'))) {
                return this.get('notifications').error('Email address entered is not valid.');
            }
            if(!this.get('user.password')) {
                return this.get('notifications').error('Password field cannot be empty.');
            }
            if(this.get('user.password') !== this.get('confirm_password')) {
                return this.get('notifications').error('Passwords entered do not match.');
            }
            Ember.$('#appLoader').show();
            // save user and continue
            user.save().then(function(user) {
                Cookies.set('userSession', user.get('id'));
                Cookies.set('userSessionToken', md5(user.get('id')));
                this.transitionToRoute('portal').then(function() {
                    this.resetForm();
                    this.send('reloadPortal');
                }.bind(this));
            }.bind(this), function(error) {
                Ember.$('#appLoader').hide();
                return this.get('notifications').error((error.errors.length) ? error.errors.join('\n') : 'Encountered server error.');
            }.bind(this));
        }
    },
    
    validateEmail: function(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    },
    
    resetForm: function() {
        this.set('user', this.store.createRecord('user', {
            first_name: null,
            last_name: null,
            email: null,
            date_of_birth: null,
            password: null,
            gender: 'male',
            account_type: 'user',
            account_status: 'active'
        }));
        this.set('confirm_password', null);9
    },
    
    user: function() {
        return this.store.createRecord('user', {
            first_name: null,
            last_name: null,
            email: null,
            date_of_birth: null,
            password: null,
            gender: 'male',
            account_type: 'user',
            account_status: 'active'
        });
    }.property('user')
});
