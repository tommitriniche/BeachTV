import Ember from 'ember';

export default Ember.Controller.extend({
    
    actions: {
        toggleSearchBar: function() {
            if(this.set('searchBarOpen')) {
                this.set('searchBarOpen', false);
            } else {
                this.set('searchBarOpen', true);
                Ember.$('.mSearchBar').focus();
            }
        }
    },
    
    isLoggedIn: function() {
        return (this.get('model.user.id'));
    }.property('user'),
    
    searchBarOpen: false,
});
