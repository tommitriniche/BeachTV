import Ember from 'ember';
import config from './config/environment';

const Router = Ember.Router.extend({
  location: config.locationType,
  rootURL: config.rootURL
});

Router.map(function() {
  this.route('auth', function() {});
  this.route('portal', {path: '/'}, function() {
    this.route('discover', {path: '/unveil'}, function() {});
    this.route('events');
    this.route('pages', {path: '/p'}, function() {
      this.route('faq');
      this.route('contact');
      this.route('tos', {path: '/terms-of-service'});
      this.route('privacy-policy');
      this.route('about');
    });
    this.route('categories');
    this.route('partners');

    this.route('auth', function() {
      this.route('login');
      this.route('register');
    });
    this.route('category', {path: '/category/:slug'});
    this.route('watch', {path: '/watch/:slug'}, function() {
      this.route('buy');
    });
    this.route('dashboard', function() {
      this.route('settings', function() {
        this.route('change-password');
      });
      this.route('my-videos');
      this.route('my-favorites');
      this.route('my-events');
      this.route('calendar');
    });
    this.route('event', {path: '/event/:slug'});
    this.route('rsvp');
    this.route('search-results');
    this.route('series', {path: '/series/:slug'});
  });
});

export default Router;
