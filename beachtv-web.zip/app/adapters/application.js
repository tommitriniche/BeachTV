import config from '../config/environment';
import DS from 'ember-data';

export default DS.RESTAdapter.extend({
	namespace: config.api.namespace,
	host: config.api.host,
});
