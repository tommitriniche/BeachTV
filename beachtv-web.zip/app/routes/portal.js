import Ember from 'ember';

export default Ember.Route.extend({
    actions: {
        loading: function() {
        	window.transitionComplete = false;
            setTimeout(function() {
            	if(window.transitionComplete === false) {
        		    Ember.$('#appLoader').fadeIn();
            	}
            }.bind(this), 700); // throw loader after half a second
            this.router.on('didTransition', this, function(){
            	window.transitionComplete = true;
                Ember.$('#appLoader').fadeOut();
            }); 
        },
        
		didTransition: function() {
			var route = this;
			// Element does not exist.
			Ember.run.scheduleOnce('afterRender', this, function() {
			});
		},
		
		reloadPortal: function() {
		    this.refresh();
		},
		
		endSession: function() {
            Cookies.expire('userSession');
            Cookies.expire('userSessionToken');
            this.refresh();
            return this.transitionTo('portal.auth.login');
        }
    },
    
    model: function() {
        return Ember.RSVP.hash({
            user: this.store.find('user', (Cookies.get('userSession') !== undefined) ? Cookies.get('userSession') : 'guest').catch(this.userNotFound.bind(this)),
            categories: this.store.query('category', {parent_cat_uuid: 'null'})
        });
    },
	
	userNotFound: function(response) {
		let controller = this.controllerFor('portal');
		controller.set('isLoggedIn', false);
	},
});
