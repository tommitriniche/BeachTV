import Ember from 'ember';

export default Ember.Route.extend({
    actions: {
        willTransition: function() {
         if (window.slideout) {
            window.slideout.close();
         } 
      },
    }
});
