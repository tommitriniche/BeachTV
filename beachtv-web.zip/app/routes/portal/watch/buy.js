import Ember from 'ember';

export default Ember.Route.extend({
    actions: {
        didTransition: function() {
            var route = this;
            Ember.run.scheduleOnce('afterRender', this, function() {
        	    Ember.$('#modal').niftyModal({
        	        afterClose: function(modal) {
        	            setTimeout(function() {
        	                return route.transitionTo('portal.watch');
        	            }, 130);
                    }
        	    });
            }); 
        }
    },
    
    model: function(params) {
        var watchModel = this.modelFor('portal.watch');
        return Ember.RSVP.hash({
            video: watchModel.video
        });
    }
});
