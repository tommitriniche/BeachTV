import Ember from 'ember';
import RouteMixin from 'ember-cli-pagination/remote/route-mixin';

export default Ember.Route.extend(RouteMixin, {
    
    queryParams: {
        searchQuery: {
            refreshModel: true
        },
        perPage: {
            refreshModel: true
        },
    },
    
    perPageParam: 'per_page',
    pageParam: 'current_page',
    totalPagesParam: 'meta.total_pages',
    
    model: function(params) {
        var slug = params.slug;
        delete params.slug;
        params.paramMapping = {
            page: 'current_page',
            perPage: 'limit'
        };
        params.order_by = 'id';
        params.order_set = 'asc';
        params.category_uuid = slug;
        return Ember.RSVP.hash({
            category: this.store.findRecord('category', slug),
            sub_categories: this.store.query('category', {parent_cat_uuid: slug}),
            videos: this.findPaged('video', params),
            series_categories: this.store.query('series-category', {category_uuid: slug}),
            series: this.store.query('series', {category_uuid: slug})
        });
    },
    
    actions: {
        doSearch: function() {
            this.refresh();
        },
        
        reloadModel: function() {
            this.refresh();
        }
    }
});
