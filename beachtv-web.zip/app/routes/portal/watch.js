import Ember from 'ember';

export default Ember.Route.extend({
    
    actions: {
        reload: function() {
            this.refresh();
        }
    },
    
    model: function(params) {
        var portalModel = this.modelFor('portal');
        return Ember.RSVP.hash({
            video: this.store.findRecord('video', params.slug),
            comments: this.store.query('comment', {object_uuid: params.slug, object_type: 'video'}),
            user: portalModel.user
        });
    },
    
    afterModel: function(model) {
        var view = this.store.createRecord('video-view', {
            video_uuid: model.video.get('id'),
            user_uuid: Cookies.get('userSession')
        });
        view.save();
    },
    
    setupController: function(controller, model) {
        this._super(controller, model);
        // get related videos
        controller.set('relatedVideos', Ember.A());
        model.video.get('tags').forEach(function(tag) {
            controller.store.query('video', {searchQuery: tag.get('name'), limit: 3}).then(function(videos) {
                // add videos
                let relatedVideos = controller.get('relatedVideos');
                let videos_arr = videos.toArray();
                let filtered = videos_arr.filter(function(video) {
                    return (video.get('id') !== model.video.get('id') && !relatedVideos.contains(video));
                });
                let add = relatedVideos.concat(filtered); //$.merge(currentProducts, results);
                controller.set('relatedVideos', add);
            });
        });
        Ember.run.scheduleOnce('afterRender', this, function() {
            var jwplayerInstance = window.jwplayer('videoPlayer');
            jwplayerInstance.setup({
                playlist: [{
                    sources: [{
                        file: model.video.get('mp4_url')
                    }, {
                        file: model.video.get('webm_url')
                    }]
                }],
                mediaid: model.video.get('id')
            });
        });
    }
});
