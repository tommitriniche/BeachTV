import Ember from 'ember';

export default Ember.Route.extend({
    model: function() {
        return Ember.RSVP.hash({
            categories: this.store.query('category', {parent_cat_uuid: 'null', cat_type: 'video', order_by: 'id', order_set: 'desc'})
        });
    }
});
