import Ember from 'ember';
import config from '../../config/environment';

export default Ember.Route.extend({
    
    actions: {
        didTransition: function() {
            var route = this;
			// Element does not exist.
			Ember.run.scheduleOnce('afterRender', this, function() {
				// initialize trailer
				// videojs('trailer-video', {'fluid': true, 'controls': true, 'autoplay': false, 'preload': 'auto', 'height': 'auto', 'width': 'auto', 'autoHeight': true, 'responsive': true}, function() {
				//   // Player (this) is initialized and ready.
				// });
				if(!window.isMobile) {
					window.home_trailer = Ember.$('#featured_video').vide({
						'mp4': 'https://dpynxpq9ltuo.cloudfront.net/assets/beachtv-trailer.mp4',
						'poster': '/images/trailer-poster.jpg'
					}, {
						'posterType': 'jpg', 
						'loop': true, 
						'autoplay': true,
						'muted': false, 
						'position': '0% 50%'	
					});
				} else {
					if(Ember.$('body').height() < 600) {
						Ember.$('#featured_video').height('200px');
					} else if(Ember.$('body').height() < 700) {
						Ember.$('#featured_video').height('300px');
					} else if(Ember.$('body').height() < 900) {
						Ember.$('#featured_video').height('500px');
					}
					Ember.$('#featured_video').css({
						'background-image': 'url(/images/trailer-poster.jpg)',
						'background-size': '100% 100%',
						'background-repeat': 'no-repeat'
					});
					Ember.$('#featured_video').append('<div class="featured-video-content text-center"><a href="https://dpynxpq9ltuo.cloudfront.net/assets/beachtv-trailer.mp4" class="white-text" style="margin-top: 50%px; font-size: 90px;"><i class="fa fa-play"></i></a></div>');
				}
			    // setup carousel on categories
			    Ember.$('#category-cards').slick({
			        centerMode: true,
			        infinite: true,
			        slidesToShow: 6,
			        slidesToScroll: 2,
			        autoplaySpeed: 2000,
			        responsive: [{
			            breakpoint: 1024,
			            settings: {
			                centerMode: true,
			                slidesToShow: 3,
			                slidesToScroll: 3,
			                infinite: true
			            }
			        }, {
			            breakpoint: 600,
			            settings: {
			                centerMode: true,
			                slidesToShow: 2,
			                slidesToScroll: 2,
			                infinite: true
			            }
			        }, {
			            breakpoint: 480,
			            settings: {
			                centerMode: true,
			                slidesToShow: 1,
			                slidesToScroll: 1,
			                infinite: true
			            }
			        }]
			    });
			});  
        },
    },
    
    model: function() {
        return Ember.RSVP.hash({
            featured_video: this.store.queryRecord('video', {featured: 1, order_by: 'id', limit: 1, query_record: 1}),
            top_four_categories: this.store.query('category', {parent_cat_uuid: 'null', cat_type: 'video', order_by: 'id', order_set: 'desc'}),
            partners: this.store.query('partner', {order_by: 'id', order_set: 'desc', limit: 4, type: 'partner'}),
            mostViewed: this.store.query('video', {get_most_viewed: 1, limit: 4})
        });
    }
});
