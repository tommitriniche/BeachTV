import Ember from 'ember';

export function initialize() {
  Ember.LinkComponent.reopen({
    attributeBindings: ['data-toggle']
  });
}

export default {
  name: 'link-to',
  initialize: initialize
};
