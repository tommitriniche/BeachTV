import Ember from 'ember';

export function initialize() {
   Ember.Route.reopen({

      activate: function() {
         // reset scroll
         window.scrollTo(0, 0); 
         // generate css class
         var cssClass = (this.bodyClass !== undefined) ? this.toCssClass() + ' ' + this.bodyClass : this.toCssClass();
         // you probably don't need the application class
         // to be added to the body
         if (cssClass !== 'application') {
            Ember.$('body').addClass(cssClass);
         }
         // if mobile device
         window.isMobile = false; //initiate as false
         // device detection
         if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
            window.isMobile = true;
         }
         // autoclear notifications
         this.get('notifications').setDefaultAutoClear(true);
         // initialize stuff for template
         Ember.run.scheduleOnce('afterRender', this, function() {
            // initialize slideout menu
            window.slideout = new Slideout({
               'panel': document.getElementById('panel'),
               'menu': document.getElementById('menu'),
               'padding': 256,
               'tolerance': 70
            });
            // fix header class
            Ember.$(window).scroll(function() {
               var scroll = Ember.$(window).scrollTop();

               if (scroll >= 100) {
                  Ember.$('.beachtv-nav').addClass('solid-header-bg');
               }
               else {
                  Ember.$('.beachtv-nav').removeClass('solid-header-bg');
               }
            });
            // modal defaults
            Ember.$.fn.niftyModal('setDefaults', {
               overlaySelector: '.modal-overlay',
               closeSelector: '.modal-close',
               classAddAfterOpen: 'modal-show',
            });
            // create animation plugin here
            Ember.$.fn.extend({
                animateCss: function (animationName) {
                    var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
                    Ember.$(this).addClass('animated ' + animationName).one(animationEnd, function() {
                        Ember.$(this).removeClass('animated ' + animationName);
                    });
                }
            });
            Ember.$(function() {
               // google chrome autocomplete disable hack
               Ember.$('input,select,textarea').attr('autocomplete', 'false');
               Ember.$('form').attr('autocomplete', 'false');
               Ember.$('input, select, textarea').attr('readonly', true);
               setTimeout(function() {
                  Ember.$('input, select, textarea').removeAttr('readonly');
               }, 200);
               // disable autocomplete
               Ember.$('form[autocomplete=off]').find('input,select,textarea').attr('autocomplete', 'false');
            });
         });
      },

      deactivate: function() {
         Ember.$('body').removeClass(this.toCssClass()).removeClass(this.bodyClass);
      },

      toCssClass: function() {
        return this.routeName.replace(/\./g, '-').dasherize();
      }

   });
}

export default {
   name: 'beachtv-web-route',
   initialize: initialize
};
