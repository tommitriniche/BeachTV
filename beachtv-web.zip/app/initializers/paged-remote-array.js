import PagedRemoteArray from 'ember-cli-pagination/remote/paged-remote-array';

export function initialize() {
    PagedRemoteArray.reopen({

        paginationLoading: false,

        fetchContent: function() {
            // Setting loading
            this.set('paginationLoading', true);
            var store = this.get('store');
            var modelName = this.get('modelName');
            var ops = this.get('paramsForBackend');
            var res = store.query(modelName, ops);
            this.incrementProperty("numRemoteCalls");
            var me = this;
            res.then(function(rows) {
                // console.log("PagedRemoteArray#fetchContent in res.then " + rows);
                var newMeta = {};
                var totalPagesField = me.get('paramMapping').total_pages;
                if (rows.meta) {
                    for (var k in rows.meta) {
                        newMeta[k] = rows.meta[k];
                        if (totalPagesField && totalPagesField === k) {
                            newMeta['total_pages'] = rows.meta[k];
                        }
                    }
                }
                // Unset loading
                me.set('paginationLoading', false);
                return me.set("meta", newMeta);
            }, function(error) {
                // Unset loading
                me.set('paginationLoading', false);
                // console.log("PagedRemoteArray#fetchContent error " + error);
            });

            return res;
        }
    });
}

export default {
    name: 'paged-remote-array',
    initialize
};
