import DS from 'ember-data';

export default DS.Model.extend({
    uuid: DS.attr('string'),
	user_uuid: DS.attr('string'),
	transaction_uuid: DS.attr('string'),
	event_uuid: DS.attr('string'),
	number_attending: DS.attr('number'),
    deleted_at: DS.attr('string'),
	created_at: DS.attr('string'),
	updated_at: DS.attr('string'),
	
	createdOn: function() {
	    return moment(this.get('created_at')).format('MM/DD/YYYY');
	}.property('created_at')
});
