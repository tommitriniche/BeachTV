import Model from 'ember-data/model';
import attr from 'ember-data/attr';
// import { belongsTo } from 'ember-data/relationships';

export default Model.extend({
    uuid: attr('string'),
    user_uuid: attr('string'),
    type: attr('string'),
    name: attr('string'),
    street_address1: attr('string'),
    street_address2: attr('string'),
    unit_number: attr('string'),
    postal_code: attr('string'),
    city: attr('string'),
    province_state: attr('string'),
    country: attr('string'),
    latitude: attr('string'),
    longitude: attr('string'),
    neighborhood: attr('string'),
    created_at: attr('string'),
    updated_at: attr('string'),
    deleted_at: attr('string'),
    
    title: function() {
        let title = '';
        if(this.get('name')) {
            title += this.get('name');
        }
        if(this.get('street_address1')) {
            title += ', ' + this.get('street_address1');
        }
        if(this.get('city')) {
            title += ', ' + this.get('city');
        }
        return title;
    }.property('name', 'street_address1', 'city')
});
