import Model from 'ember-data/model';
import attr from 'ember-data/attr';
// import { belongsTo, hasMany } from 'ember-data/relationships';

export default Model.extend({
    uuid: attr('string'),
    user_uuid: attr('string'),
    video_uuid: attr('string'),
    deleted_at: attr('string'),
	created_at: attr('string'),
	updated_at: attr('string'),
    
    viewedAgo: function() {
        return moment(this.get('created_at')).fromNow();
    }.property('created_at'),
    
    prettyDate: function() {
        return moment(this.get('created_at')).format('MMM Do YYYY');
    }.property('created_at')
});
