import Model from 'ember-data/model';
import attr from 'ember-data/attr';
import { belongsTo, hasMany } from 'ember-data/relationships';

export default Model.extend({
    uuid: attr('string'),
    title: attr('string'),
    meta: attr('raw'),
    cat: attr('raw'),
    content: attr('string'),
    price: attr('string'),
    views_count: attr('number'),
    path: attr('string'),
    file_uuid: attr('string'),
    category_uuid: attr('string'),
    category: belongsTo('category'),
    tagList: attr('string'),
    mp4_url: attr('string'),
    webm_url: attr('string'),
    gif_url: attr('string'),
    jpg_url: attr('string'),
    poster_url: attr('string'),
    slug: attr('string'),
    file: belongsTo('file', {async: false}),
    tags: hasMany('tag', {async: false}),
    encoding_complete: attr('boolean'),
    featured: attr('boolean'),
    deleted_at: attr('string'),
	created_at: attr('string'),
	updated_at: attr('string'),
	
	displayPrice: function() {
	    return (this.get('price')/100).toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,')
	}.property('price'),
	
	src: function() {
	    return [
            { src: this.get('mp4_url'), type: 'video/mp4' },
            { src: this.get('webm_url'), type: 'video/webm' }
          ];
	}.property('mp4_url', 'webm_url'),
	
	duration: function() {
	    if(this.get('meta.source')) {
	        return moment().startOf('day').seconds(this.get('meta.source.format.duration')).format('H:mm:ss');
	    }
	    return moment().startOf('day').seconds(0).format('H:mm:ss');
	}.property('meta'),
	
	durationInMinutes: function() {
	    if(this.get('meta.source')) {
	        return moment().startOf('day').seconds(this.get('meta.source.format.duration')).format('mm');
	    }
	    return moment().startOf('day').seconds(0).format('mm');
	}.property('meta'),
    
    excerpt: function() {
 		return (this.get('content.length') > 200) ? Ember.String.htmlSafe(this.get('content').substring(0, 200) + '...') : Ember.String.htmlSafe(this.get('content'));
 	}.property('content'),
    
    uploadedTimeAgo: function() {
        return moment(this.get('created_at')).fromNow();
    }.property('created_at'),
    
    prettyDate: function() {
        return moment(this.get('created_at')).format('MMM Do YYYY');
    }.property('created_at')
});
