import DS from 'ember-data';
import { belongsTo, hasMany } from 'ember-data/relationships';

export default DS.Model.extend({
    uuid: DS.attr('string'),
	name: DS.attr('string'),
	category_uuid: DS.attr('string'),
	series_uuid: DS.attr('string'),
	series_title: DS.attr('string'),
	series: belongsTo('series'),
    deleted_at: DS.attr('string'),
	created_at: DS.attr('string'),
	updated_at: DS.attr('string'),
	
	createdOn: function() {
	    return moment(this.get('created_at')).format('MM/DD/YYYY');
	}.property('created_at')
});
