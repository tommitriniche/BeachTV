import DS from 'ember-data';

export default DS.Model.extend({
    uuid: DS.attr('string'),
	user_uuid: DS.attr('string'),
	authorName: DS.attr('string'),
	object_uuid: DS.attr('string'),
	object_type: DS.attr('string'),
	parent_uuid: DS.attr('string'),
	order: DS.attr('string'),
	content: DS.attr('string'),
	link: DS.attr('string'),
	permalink: DS.attr('string'),
	views: DS.attr('number'),
	notify_owner_replies: DS.attr('number'),
    deleted_at: DS.attr('string'),
	created_at: DS.attr('string'),
	updated_at: DS.attr('string'),
	
	postedAgo: function() {
        return moment(this.get('created_at')).fromNow();
    }.property('created_at'),
	
	postedOn: function() {
	    return moment(this.get('created_at')).format('MM/DD/YYYY');
	}.property('created_at'),
});
