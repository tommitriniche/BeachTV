import DS from 'ember-data';

export default DS.RESTSerializer.extend(DS.EmbeddedRecordsMixin, {
    primaryKey: 'uuid',
    attrs: {
        tags: {embedded: 'always'},
        file: {embedded: 'always'},
        meta: {embedded: 'always'},
        category: {embedded: 'always'},
    }
});
