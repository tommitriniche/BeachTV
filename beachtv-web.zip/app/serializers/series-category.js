import DS from 'ember-data';

export default DS.RESTSerializer.extend(DS.EmbeddedRecordsMixin, {
    primaryKey: 'uuid',
    attrs: {
        series: {embedded: 'always'}
    }
});
