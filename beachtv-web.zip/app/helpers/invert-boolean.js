import Ember from 'ember';

export function invertBoolean(params) {
    var boolean = params[0];
    return (boolean) ? false : true;
}

export default Ember.Helper.helper(invertBoolean);
