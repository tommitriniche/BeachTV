import Ember from 'ember';

export function styleUrlBgCover(params) {
  var url = params[0];
  return "background: url('" + url + "'); background-size: cover;";
}

export default Ember.Helper.helper(styleUrlBgCover);
