import Ember from 'ember';

export function numberFormat(params) {
    return params[0].toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

export default Ember.Helper.helper(numberFormat);
