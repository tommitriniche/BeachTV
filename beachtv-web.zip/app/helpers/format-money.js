import Ember from 'ember';

export function formatMoney(params) {
    return params[0].toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
}

export default Ember.Helper.helper(formatMoney);
