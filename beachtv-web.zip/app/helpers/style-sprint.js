import Ember from 'ember';

export function styleSprint(params) {
    var style = params[0];
    params.shift();
    return vsprintf(style, params);
}

export default Ember.Helper.helper(styleSprint);
