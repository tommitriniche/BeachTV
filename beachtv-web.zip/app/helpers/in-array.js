import Ember from 'ember';

export function inArray(params) {
    var item = params[0];
    var array = params[1];
    return (array.filter(function(i) { return i == item; }).length > 0);
}

export default Ember.Helper.helper(inArray);
