import Ember from 'ember';

export function isLoggedIn(params) {
  return (Cookies.get('userSession') !== undefined);
}

export default Ember.Helper.helper(isLoggedIn);
