import Ember from 'ember';

export function notString(params) {
    var string = params[0];
    return (typeof string === "string");
}

export default Ember.Helper.helper(notString);
