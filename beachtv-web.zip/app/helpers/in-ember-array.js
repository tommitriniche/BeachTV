import Ember from 'ember';

export function inEmberArray(params) {
    var element = params[0];
    var array = params[1];
    return (array.contains(element));
}

export default Ember.Helper.helper(inEmberArray);
