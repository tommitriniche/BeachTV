import Ember from 'ember';

export function phoneFormat(params) {
  return (params[0] !== null) ? params[0].replace(/(\d\d\d)(\d\d\d)(\d\d\d\d)/, "($1) $2-$3") : params[0];
}

export default Ember.Helper.helper(phoneFormat);
