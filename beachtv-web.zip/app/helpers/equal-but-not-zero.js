import Ember from 'ember';

export function equalButNotZero(params) {
    let valueOne = params[0];
    let valueTwo = params[1];
    if(parseInt(valueOne) === 0 && parseInt(valueTwo) === 0) {
        return false;
    }
    return (valueOne === valueTwo);
}

export default Ember.Helper.helper(equalButNotZero);
