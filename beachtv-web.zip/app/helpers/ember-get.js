import Ember from 'ember';

export function getProperty(params) {
    let obj = params[0];
    let property = params[1];
    if(typeof Ember.get(obj, property) === 'string' && ((Ember.get(obj, property)).toLowerCase().indexOf('.jpg') !== -1 || (Ember.get(obj, property)).toLowerCase().indexOf('.png') !== -1 || (Ember.get(obj, property)).toLowerCase().indexOf('.gif') !== -1)) {
        // if image return as a thumbnail
        return Ember.String.htmlSafe('<img src="' + Ember.get(obj, property) + '" class="thumbnail" style="width: 50px; height: 50px;">');
    }
    return Ember.get(obj, property);
}

export default Ember.Helper.helper(getProperty);
