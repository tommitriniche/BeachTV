import Ember from 'ember';

export function isValidUuid(params) {
    var uuid = params[0];
    return /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/.test(uuid);
}

export default Ember.Helper.helper(isValidUuid);
