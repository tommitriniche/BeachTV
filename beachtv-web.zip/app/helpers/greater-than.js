import Ember from 'ember';

export function greaterThan(params) {
    let valueOne = parseInt(params[0]);
    let valueTwo = parseInt(params[1]);
    return (valueOne > valueTwo);
}

export default Ember.Helper.helper(greaterThan);
