import Ember from 'ember';

export function momentFormat(params) {
    var date = params[0];
    var format = params[1];
    var is_unix = (params[2] !== undefined) ? params[2] : false;
    return (is_unix) ? moment.unix(date).format(format) : moment(date).format(format);
}

export default Ember.Helper.helper(momentFormat);
