import Ember from 'ember';

export function equal(params) {
    let valueOne = params[0];
    let valueTwo = params[1];
    return (valueOne === valueTwo);
}

export default Ember.Helper.helper(equal);
