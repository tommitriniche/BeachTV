import Ember from 'ember';

export function styleBg(params) {
    var url = params[0];
    var size = (params[1] !== undefined) ? params[1] : 'cover';
    return "background: url('" + url + "'); background-size: " + size + ";";
}

export default Ember.Helper.helper(styleBg);
