import Ember from 'ember';

export default Ember.Component.extend({
    
    value: null,
    unix_to_date: null,
    
    didInsertElement: function() {
        var element = $(this.$('.jq-datepicker'));
        element.datepicker();
        element.change(function() {
           this.set('value', element.val()); 
        }.bind(this));
        if(this.get('value') !== null) {
            if(this.get('unix_to_date') === true && this.get('value').indexOf('/') === -1) {
                this.set('value', moment.unix(this.get('value')).format('MM/DD/YYYY'));
            }
            element.val(this.get('value'));
        }
    }
    
});
