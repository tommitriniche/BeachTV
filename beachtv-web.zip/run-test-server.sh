rm nohup.out
nohup ember server --environment test --port 5566 &>/dev/null &
