rm nohup.out
nohup ember server --environment test --port 5577 &>/dev/null &
