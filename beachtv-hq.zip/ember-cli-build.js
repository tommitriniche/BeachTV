/*jshint node:true*/
/* global require, module */
var EmberApp = require('ember-cli/lib/broccoli/ember-app');
var Funnel = require('broccoli-funnel');
var MergeTrees = require('broccoli-merge-trees');

module.exports = function(defaults) {
  var app = new EmberApp(defaults, {
    // Add options here
  });

  // Use `app.import` to add additional libraries to the generated
  // output files.
  //
  // If you need to use different assets in different
  // environments, specify an object as the first parameter. That
  // object's keys should be the environment name and the values
  // should be the asset to use in that environment.
  //
  // If the library that you are including contains AMD or ES6
  // modules that you would like to import into your application
  // please specify an object with the list of modules as keys
  // along with the exports of each module as its value.
  
  // Stylesheets
  app.import('vendor/modern/plugins/pace-master/themes/blue/pace-theme-flash.css');
  app.import('vendor/modern/plugins/uniform/css/uniform.default.min.css');
  app.import('bower_components/bootstrap/dist/css/bootstrap.min.css');
  app.import('vendor/modern/plugins/waves/waves.min.css');
  app.import('vendor/modern/plugins/switchery/switchery.min.css');
  app.import('vendor/modern/plugins/3d-bold-navigation/css/style.css');
  app.import('vendor/modern/plugins/metrojs/MetroJs.min.css');
  app.import('vendor/modern/plugins/slidepushmenus/css/component.css');
  app.import('vendor/modern/css/modern.css');
  app.import('bower_components/mdi/css/materialdesignicons.min.css');
  app.import('bower_components/fineuploader-dist/dist/fine-uploader.min.css');
  app.import('bower_components/pnotify/dist/pnotify.css');
  app.import('bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker3.min.css');
  app.import('bower_components/jt.timepicker/jquery.timepicker.css');
  app.import('bower_components/bootstrap-tagsinput/dist/bootstrap-tagsinput.css');
  app.import('bower_components/vex/dist/css/vex.css');
  app.import('bower_components/vex/dist/css/vex-theme-os.css');
  
  // Fonts
  var mdiFonts = new Funnel('bower_components/mdi/fonts', {destDir: 'fonts'});
  var bootstrapFonts = new Funnel('bower_components/bootstrap/dist/fonts', {destDir: 'fonts'});
  
  // FineUploader Images
  app.import('bower_components/fineuploader-dist/dist/edit.gif', { destDir: 'assets' });
  app.import('bower_components/fineuploader-dist/dist/loading.gif', { destDir: 'assets' });
  app.import('bower_components/fineuploader-dist/dist/pause.gif', { destDir: 'assets' });
  app.import('bower_components/fineuploader-dist/dist/processing.gif', { destDir: 'assets' });
  app.import('bower_components/fineuploader-dist/dist/retry.gif', { destDir: 'assets' });
  app.import('bower_components/fineuploader-dist/dist/continue.gif', { destDir: 'assets' });
  app.import('bower_components/fineuploader-dist/dist/trash.gif', { destDir: 'assets' });
  
  // Javascript
  
  app.import('vendor/modern/plugins/jquery-ui/jquery-ui.min.js');
  app.import('vendor/modern/plugins/pace-master/pace.min.js');
  app.import('vendor/modern/plugins/jquery-blockui/jquery.blockui.js');
  app.import('bower_components/bootstrap/dist/js/bootstrap.min.js');
  app.import('vendor/modern/plugins/jquery-slimscroll/jquery.slimscroll.min.js');
  app.import('vendor/modern/plugins/uniform/jquery.uniform.min.js');
  app.import('vendor/modern/plugins/classie/classie.js');
  app.import('vendor/modern/plugins/waves/waves.js');
  app.import('vendor/modern/plugins/switchery/switchery.min.js');
  app.import('vendor/modern/plugins/3d-bold-navigation/js/main.js');
  app.import('vendor/modern/plugins/metrojs/MetroJs.min.js');
  app.import('vendor/modern/plugins/metrojs/MetroJs.min.js');
  app.import('bower_components/pnotify/dist/pnotify.js');
  app.import('bower_components/moment/min/moment.min.js');
  app.import('bower_components/numeral/min/numeral.min.js');
  app.import('bower_components/underscore/underscore-min.js');
  app.import('bower_components/blueimp-md5/js/md5.min.js');
  app.import('bower_components/cookies-js/dist/cookies.min.js');
  app.import('bower_components/fineuploader-dist/dist/s3.jquery.fine-uploader.min.js');
  app.import('bower_components/vex/dist/js/vex.combined.min.js');
  
  app.import('bower_components/jquery.inputmask/dist/jquery.inputmask.bundle.js');
  app.import('bower_components/jquery.maskedinput/dist/jquery.maskedinput.min.js');
  app.import('bower_components/jquery-maskmoney/dist/jquery.maskMoney.min.js');
  app.import('bower_components/ckeditor/ckeditor.js');
  app.import('bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js');
  app.import('bower_components/jt.timepicker/jquery.timepicker.min.js');
  app.import('bower_components/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js');
  app.import('bower_components/excellentexport/excellentexport.min.js');
    
  app.import('vendor/modern/js/3dnav.js');
  app.import('vendor/modern/js/modern.js');

  return app.toTree(new MergeTrees([mdiFonts, bootstrapFonts], {overwrite: true}));
};
