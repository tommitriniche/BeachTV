import { moduleFor, test } from 'ember-qunit';

moduleFor('controller:dashboard/categories/index/edit', 'Unit | Controller | dashboard/categories/index/edit', {
  // Specify the other units that are required for this test.
  // needs: ['controller:foo']
});

// Replace this with your real tests.
test('it exists', function(assert) {
  let controller = this.subject();
  assert.ok(controller);
});
