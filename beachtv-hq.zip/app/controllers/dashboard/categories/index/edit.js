import Ember from 'ember';

export default Ember.Controller.extend({
    actions: {
        save: function() {
            var cat = this.get('model.category');
            cat.save().then(function() {
                this.set('upload', null);
                this.get('notifications').success('Category details saved.');
                return this.transitionToRoute('dashboard.categories.index');
            }.bind(this));
        },
        
        /**
         * closes the modal
         * @return null
         */
        closeModal: function() {
            this.set('upload', null);
            return this.transitionToRoute('dashboard.categories.index');
        },
        
    },
    
    /**
     * create a temp id for uploads
     * @return string
     */
    tempid: function() {
        return md5(moment.unix());
    }.property(),
    
    /**
     * the image uploaded
     * @return array
     */
    upload: null,
    
    /**
     * Handle file uploads by saving them to a temp array to be fixed with the 
     * event id as the key upon saving the event
     */
    handleUpload: function() {
        var upload = this.get('upload');
        if(upload === null) {
            return;
        }
        this.set('model.category.thumbnail_file_uuid', upload.uuid);
    }.observes('upload'),
    
    categories: function() {
        return this.store.peekAll('category').filter(function(cat) {
            return (cat.get('id') !== null);
        });
    }.property('category')
});
