import Ember from 'ember';

export default Ember.Controller.extend({
    actions: {
        create: function() {
            var series = this.get('series');
            series.save().then(function() {
                this.get('notifications').success('New series created.');
            }.bind(this));
        },
    },
    
    /**
     * create a temp id for uploads
     * @return string
     */
    tempid: function() {
        return md5(moment.unix());
    }.property(),
    
    /**
     * the image uploaded
     * @return array
     */
    upload: null,
    
    /**
     * Handle file uploads by saving them to a temp array to be fixed with the 
     * event id as the key upon saving the event
     */
    handleUpload: function() {
        var upload = this.get('upload');
        if(upload === null) {
            return;
        }
        this.set('series.poster_uuid', upload.uuid);
    }.observes('upload'),
    
    /**
     * reset the ivr notification email
     * @return null
     */
    resetForm: function() {
        this.set('upload', null);
        this.set('series', this.store.createRecord('series', {
            title: null,
            description: null,
            long_description: null,
            production_year: null,
            duration: null,
            production_house: null,
            format: null,
            broadcasters: null,
            genre: null
        }));
    },
    
    series: function() {
        return this.store.createRecord('series', {
            title: null,
            description: null,
            long_description: null,
            production_year: null,
            duration: null,
            production_house: null,
            format: null,
            broadcasters: null,
            genre: null
        });
    }.property('series'),

});
