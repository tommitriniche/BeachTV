import Ember from 'ember';

export default Ember.Controller.extend({
    actions: {
        save: function() {
            var controller = this;
            var series = this.get('model.series');
            series.save().then(function(series) {
                controller.get('selectedCategoriesQueue').forEach(function(category) {
                    var seriesCategory = controller.store.createRecord('series-category', {
                        category_uuid: category.get('id'),
                        series_uuid: series.get('id')
                    }); 
                    seriesCategory.save();
                });
                controller.set('upload', null);
                controller.get('notifications').success('Series details saved.');
                return controller.transitionToRoute('dashboard.series.index');
            });
        },
    
        /**
         * selects a company and adds it queue
         * @return null
         */
        selectCategory: function(cat) {
            var queue = this.get('selectedCategoriesQueue');
            if(!queue.contains(cat)) {
                cat.set('isChecked', true);
                queue.pushObject(cat);
            } else {
                cat.set('isChecked', false);
                queue.removeObject(cat);
            }
            this.set('selectedCategoriesQueue', queue);
        },
    },
    
    selectedCategoriesQueue: Ember.A(),
    
    /**
     * create a temp id for uploads
     * @return string
     */
    tempid: function() {
        return md5(moment.unix());
    }.property(),
    
    /**
     * the image uploaded
     * @return array
     */
    upload: null,
    
    /**
     * Handle file uploads by saving them to a temp array to be fixed with the 
     * event id as the key upon saving the event
     */
    handleUpload: function() {
        var upload = this.get('upload');
        if(upload === null) {
            return;
        }
        this.set('model.series.poster_uuid', upload.uuid);
    }.observes('upload'),
});
