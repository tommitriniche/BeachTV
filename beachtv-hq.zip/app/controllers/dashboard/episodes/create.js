import Ember from 'ember';

export default Ember.Controller.extend({
    actions: {
        create: function() {
            var episode = this.get('episode');
            episode.save().then(function() {
                this.get('notifications').success('New episode created.');
            }.bind(this));
        },
    },
    
    /**
     * create a temp id for uploads
     * @return string
     */
    tempid: function() {
        return md5(moment.unix());
    }.property(),
    
    /**
     * the image uploaded
     * @return array
     */
    upload: null,
    
    /**
     * Handle file uploads by saving them to a temp array to be fixed with the 
     * event id as the key upon saving the event
     */
    handleUpload: function() {
        var upload = this.get('upload');
        if(upload === null) {
            return;
        }
        this.set('episode.poster_uuid', upload.uuid);
    }.observes('upload'),
    
    /**
     * reset the ivr notification email
     * @return null
     */
    resetForm: function() {
        this.set('upload', null);
        this.set('episode', this.store.createRecord('episode', {
            title: null,
            description: null,
            season: null,
            number: null,
            release_date: null
        }));
    },
    
    episode: function() {
        return this.store.createRecord('episode', {
            title: null,
            description: null,
            season: null,
            number: null,
            release_date: null
        });
    }.property('episode'),

});
