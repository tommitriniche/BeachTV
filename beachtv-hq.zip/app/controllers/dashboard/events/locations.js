import Ember from 'ember';

export default Ember.Controller.extend({
    
    actions: {
        /**
         * creates an address
         * @return null
         */
        create: function() {
            this.set('savingAddress', true);
            var address = this.get('address');
            address.save().then(function() {
                this.resetForm();
                this.set('savingAddress', false);
                this.set('creatingLocation', false);
            }.bind(this)).catch(function(errorResponse) {
                if(errorResponse.errors) {
                    this.set('savingAddress', false);
				    return this.get('notifications').error(errorResponse.errors[0].detail);
                } else {
                    this.resetForm();
                    this.set('savingAddress', false);
                    this.set('creatingLocation', false);
                }
            }.bind(this));
        },
        
        /**
         * delete an address
         * @return null
         */
        deleteAddress: function(id) {
           var address = this.store.peekRecord('address', id);
           vex.dialog.confirm({
                message: 'Are you sure you want to delete this location?',
                callback: function(response) {
                    if(response === true) {
                        address.destroyRecord();
                    }   
                }.bind(this)
            });
        },
        
        /**
         * closes the modal
         * @return null
         */
        closeModal: function() {
            return this.transitionToRoute(this.get('backLink'));
        },
        
        /**
         * start creating a location
         * @return null
         */
        createLocationToggle: function() {
            this.set('creatingLocation', (this.get('creatingLocation')) ? false : true);
        },
        
    },
    
    /**
     * the default back link
     * @return string
     */
    backLink: 'dashboard.events.index',

    /**
     * reset the form
     * @return null
     */
    resetForm: function() {
        this.set('address', this.store.createRecord('address', {
            user_uuid: Cookies.get('userSession'),
            type: 'event_address',
            country: 'SG'
        }));
    },
    
    /**
     * determines if a new address is being saved
     * @return boolean
     */
    savingAddress: false,
    
    /**
     * determines if location is being created
     * @return boolean
     */
    creatingLocation: function() {
        return (this.get('model.locations.length') > 0) ? false : true;
    }.property('model.locations.length'),
    
    /**
     * the address object
     * @return DS.Model
     */
    address: function() {
        return this.store.createRecord('address', {
            user_uuid: Cookies.get('userSession'),
            type: 'event_address',
            country: 'SG'
        });
    }.property('address'),
    
    /**
     * all event locations
     * @return array
     */
    eventLocations: function() {
        return this.store.filter('address', function(address) {
            return (address.get('id') !== null && address.get('type') === 'event_address');
        });
    }.property('address')
    
});
