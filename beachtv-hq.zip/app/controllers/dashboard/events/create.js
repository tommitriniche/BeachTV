import Ember from 'ember';

export default Ember.Controller.extend({
    
    actions: {
        /**
         * the function to create the event
         * @return null
         */
        create: function() {
            Ember.$('#appLoader').fadeIn();
            var event = this.get('event');
            if(event.get('repeat_interval') === 'week') {
                event.set('repeat_dow', this.get('event_multi_dow').join(','));
            }
            event.set('tempid', this.get('tempid'));
            event.save().then(function(evt) {
                Ember.$('#appLoader').fadeOut();
                this.resetForm();
                this.get('notifications').success('Event Created!', 'Your new event has been saved.');
                return this.transitionToRoute('dashboard.events.index');
            }.bind(this), function(errorResponse) {
                Ember.$('#appLoader').fadeOut();
                return this.get('notifications').error(errorResponse);
                // return swal('Error Occured.', errorResponse.errors[0].detail, 'error');
            }.bind(this));
        },
        
        /**
         * make it so the event does not stop repeating
         * @return null
         */
        neverStopRepeating: function() {
            this.set('event.end_repeat', false);
        },
        
        /**
         * make it so the event does not stop repeating
         * @return null
         */
        setEndRepeatDate: function() {
            this.set('event.end_repeat', moment().add(6, 'months').format('MM/DD/YYYY'));
        },
        
        /**
         * save the thumbnail image caption
         * @return null
         */
        saveCaption: function() {
            Ember.$('#appLoader').fadeIn();
            this.store.findRecord('file', this.get('upload.uuid')).then(function(photo) {
               photo.set('caption', this.get('photoCaption'));
               photo.save().then(function() {
                    this.get('notifications').success('Caption saved.');
                    Ember.$('#appLoader').fadeOut();
                }.bind(this));
            }.bind(this));
        }
    
    },
    
    /**
     * all locations applicable for event
     * @return array
     */
    eventLocations: function() {
        return this.store.filter('address', function(address) {
            return (address.get('id') !== null && address.get('type') === 'event_address');
        });
    }.property('address'),
    
    /**
     * all categories applicable for event
     * @return array
     */
    eventCategories: function() {
        return this.store.peekAll('category').filter(function(cat) {
            return (cat.get('id') !== null);
        });
    }.property('category'),
    
    /**
     * create a temp id for uploads
     * @return string
     */
    tempid: function() {
        return md5(moment.unix());
    }.property(),
    
    /**
     * the image uploaded
     * @return array
     */
    upload: null,
    
    /**
     * Handle file uploads by saving them to a temp array to be fixed with the 
     * event id as the key upon saving the event
     */
    handleUpload: function() {
        var upload = this.get('upload');
        if(upload === null) {
            return;
        }
        this.set('event.photo_uuid', upload.uuid);
    }.observes('upload'),
    
    /**
     * the event we are creating
     * @return DS.Model
     */
    event: function() {
        return this.store.createRecord('event', {
            user_uuid: Cookies.get('userSession'),
            address_uuid: null,
            category_uuid: null,
            start_date: moment().format('MM/DD/YYYY'),
            start_time: '7:00pm',
            end_date: moment().format('MM/DD/YYYY'),
            end_time: '9:00pm',
            repeat_interval: 'none',
            repeat_interval_count: 1,
            repeat_frequency: 1,
            repeat_dow: 'Sat',
            end_repeat: false,
            payment_method: 'ONLINE',
            attendee_limit: 0,
            status: 'PUBLISHED',
            photo_uuid: null
        });
    }.property('event'),
    
    /**
     * reset the form
     * @return null
     */
    resetForm: function() {
        this.set('tempid', md5(moment.unix()));
        this.set('uploads', Ember.A());
        this.set('upload', null);
        this.set('event', this.store.createRecord('event', {
            user_uuid: Cookies.get('userSession'),
            address_uuid: null,
            category_uuid: null,
            start_date: moment().format('MM/DD/YYYY'),
            start_time: '7:00pm',
            end_date: moment().format('MM/DD/YYYY'),
            end_time: '9:00pm',
            repeat_interval: 'none',
            repeat_interval_count: 1,
            repeat_frequency: 1,
            repeat_dow: 'Sat',
            end_repeat: false,
            payment_method: 'ONLINE',
            attendee_limit: 0,
            status: 'PUBLISHED'
        }));
    },
    
    /**
     * the events multiple days of week array
     * @return Ember.NativeArray
     */
    event_multi_dow: function() {
        return Ember.A();
    }.property(),
    
    /**
     * the days of the week in an array (abbreviated)
     * @return array
     */
    days_of_week: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    
    /**
     * the available payment options
     * @return array
     */
    payment_options: ['ONLINE', 'OFFLINE'],
    
    /**
     * the frequency of weeks available
     * @return array
     */
    week_freq_options: [
        {label: '1 week', val: 1}, 
        {label: '2 weeks', val: 2},
        {label: '3 weeks', val: 3},
        {label: '4 weeks', val: 4},
        {label: '5 weeks', val: 5},
        {label: '6 weeks', val: 6},
        {label: '7 weeks', val: 7},
        {label: '8 weeks', val: 8},
        {label: '9 weeks', val: 9},
        {label: '10 weeks', val: 10}
    ],
    
    /**
     * the frequency of weeks available
     * @return array
     */
    month_freq_options: [
        {label: '1 month', val: 1}, 
        {label: '2 months', val: 2},
        {label: '3 months', val: 3},
        {label: '4 months', val: 4},
        {label: '5 months', val: 5},
        {label: '6 months', val: 6},
        {label: '7 months', val: 7},
        {label: '8 months', val: 8},
        {label: '9 months', val: 9},
        {label: '10 months', val: 10},
        {label: '11 months', val: 11},
        {label: '12 months', val: 12}
    ],
    
    /**
     * the frequency of days fo the week
     * @return array
     */
    dow_frequencies: [
        {label: 'first', val: 1}, 
        {label: 'second', val: 2},
        {label: 'third', val: 3},
        {label: 'fourth', val: 4},
        {label: 'last', val: 5}
    ],
    
    /**
     * event status options
     * @return array
     */
    status_options: ['PUBLISHED', 'DRAFT'],
    
    /**
     * the day of the first event
     * @return string
     */
    firstEventDay: function() {
        return moment(new Date(this.get('event.start_date'))).format('MMMM Do YYYY');
    }.property('event.start_date'),
    
});
