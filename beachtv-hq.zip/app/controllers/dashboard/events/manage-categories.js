import Ember from 'ember';

export default Ember.Controller.extend({
    actions: {
        create: function() {
            var cat = this.get('category');
            cat.save().then(function() {
                this.resetForm();
                this.get('notifications').success('New category created.');
                return this.transitionToRoute('dashboard.events.create');
            }.bind(this));
        },
        
        /**
         * closes the modal
         * @return null
         */
        closeModal: function() {
            this.resetForm();
            return this.transitionToRoute('dashboard.events.create');
        },
        
        /**
         * save the thumbnail image caption
         * @return null
         */
        saveCaption: function() {
            Ember.$('#appLoader').fadeIn();
            this.store.findRecord('file', this.get('upload.uuid')).then(function(photo) {
               photo.set('caption', this.get('photoCaption'));
               photo.save().then(function() {
                    this.get('notifications').success('Caption saved.');
                    Ember.$('#appLoader').fadeOut();
               }.bind(this));
            }.bind(this));
        }
    },
    
    /**
     * create a temp id for uploads
     * @return string
     */
    tempid: function() {
        return md5(moment.unix());
    }.property(),
    
    /**
     * the image uploaded
     * @return array
     */
    upload: null,
    
    /**
     * Handle file uploads by saving them to a temp array to be fixed with the 
     * event id as the key upon saving the event
     */
    handleUpload: function() {
        var upload = this.get('upload');
        if(upload === null) {
            return;
        }
        this.set('category.thumbnail_file_uuid', upload.uuid);
    }.observes('upload'),
    
    /**
     * reset the ivr notification email
     * @return null
     */
    resetForm: function() {
        this.set('category', this.store.createRecord('category', {
            name: null,
            parent_cat_uuid: null,
            description: null,
            cat_type: 'event'
        }));
    },
    
    category: function() {
        return this.store.createRecord('category', {
            name: null,
            parent_cat_uuid: null,
            description: null,
            cat_type: 'video'
        });
    }.property('category'),
    
    categories: function() {
        return this.store.peekAll('category').filter(function(cat) {
            return (cat.get('id') !== null);
        });
    }.property('category')
});
