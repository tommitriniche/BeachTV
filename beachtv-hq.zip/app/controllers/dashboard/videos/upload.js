import Ember from 'ember';

export default Ember.Controller.extend({
    
    /**
     * query paramets binding to controller to route
     * @return array
     */
    queryParams: ['page', 'perPage', 'searchQuery'],

    /**
     * query param bindings
     * @return various
     */
    page: 1,
    perPage: 24,
    searchQuery: null,
    
    actions: {
        
        deleteVideo: function(video) {
            Ember.$('#'+video.get('id')).animate({'opacity': '.5'});
            video.destroyRecord();
        },
        
        /**
         * doseatch clone
         * @return null
         */
        doSearch: function() {
            // do nothing
        },
    },
    
    /**
     * the max number of page per options and min
     * @return array
     */
    perPageOptions: [24, 48, 60, 84, 144, 288, 368],
    
    /**
     * searches the data when the searchQuery param receives input
     * @return null
     */
    doSearch: function() {
        if(this.get('searchQuery') !== undefined && this.get('searchQuery') !== null && this.get('searchQuery.length') > 0) {
            this.send('doSearch');
        }
    }.observes('searchQuery'),
    
    upload: Ember.A(),
    
    userKey: function() {
        return 'uploads/sys/videos';
    }.property(),
    
    completedUploads: Ember.A(),
    
    createVideoRecord: function() {
        var completedUploads = this.get('completedUploads');
        this.get('upload').forEach(function(file) {
            if(!completedUploads.includes(file.uuid)) {
                completedUploads.push(file.uuid);
                let video = this.store.createRecord('video', {
                    file_uuid: file.uuid,
                    title: '',
                    description: '',
                    path: file.key
                });
                video.save();
            }
        }.bind(this));
        if(completedUploads.length > 0 && completedUploads.length >= this.get('completedUploads.length')) {
            this.get('target.router').refresh();
        }
        this.set('completedUploads', completedUploads);
    }.observes('upload.[]'),
});
