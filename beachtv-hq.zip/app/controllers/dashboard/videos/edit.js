import Ember from 'ember';

export default Ember.Controller.extend({
    actions: {
        save: function() {
            var controller = this;
            var vid = this.get('model.video');
            vid.save().then(function() {
                controller.get('selectedCategoriesQueue').forEach(function(category) {
                    var vidCategory = controller.store.createRecord('video-category', {
                        category_uuid: category.get('id'),
                        video_uuid: vid.get('id')
                    }); 
                    vidCategory.save();
                });
                controller.get('notifications').success('Video details saved.');
            });
        },
        
        /**
         * selects a company and adds it queue
         * @return null
         */
        selectCategory: function(cat) {
            var queue = this.get('selectedCategoriesQueue');
            if(!queue.contains(cat)) {
                cat.set('isChecked', true);
                queue.pushObject(cat);
            } else {
                cat.set('isChecked', false);
                queue.removeObject(cat);
            }
            this.set('selectedCategoriesQueue', queue);
        },
    },
    
    selectedCategoriesQueue: Ember.A()

});
