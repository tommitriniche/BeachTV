import Ember from 'ember';

export default Ember.Controller.extend({
    actions: {
        create: function() {
            var partner = this.get('partner');
            partner.save().then(function() {
                this.get('notifications').success('New partner created.');
                this.send('closeModal');
            }.bind(this));
        },
        
        /**
         * closes the modal
         * @return null
         */
        closeModal: function() {
            this.resetForm();
            return this.transitionToRoute('dashboard.partners.index').then(function() {
                this.get('target.router').refresh();
            }.bind(this));
        }
    },
    
    /**
     * create a temp id for uploads
     * @return string
     */
    partnerTypes: ['partner', 'sponsor'],
    
    /**
     * create a temp id for uploads
     * @return string
     */
    tempid: function() {
        return md5(moment.unix());
    }.property(),
    
    /**
     * the image uploaded
     * @return array
     */
    upload: null,
    
    /**
     * Handle file uploads by saving them to a temp array to be fixed with the 
     * event id as the key upon saving the event
     */
    handleUpload: function() {
        var upload = this.get('upload');
        if(upload === null) {
            return;
        }
        this.set('partner.logo_file_uuid', upload.uuid);
    }.observes('upload'),
    
    /**
     * reset the ivr notification email
     * @return null
     */
    resetForm: function() {
        this.set('upload', null);
        this.set('partner', this.store.createRecord('partner', {
            name: null,
            logo_file_uuid: null,
            description: null,
            type: 'partner'
        }));
    },
    
    partner: function() {
        return this.store.createRecord('partner', {
            name: null,
            logo_file_uuid: null,
            description: null,
            type: 'partner'
        });
    }.property('partner')
});
