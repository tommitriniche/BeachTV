import Ember from 'ember';

export default Ember.Controller.extend({
    actions: {
        save: function() {
            var partner = this.get('model.partner');
            partner.save().then(function() {
                this.get('notifications').success('Partner info updated.');
                return this.transitionToRoute('dashboard.partners.index');
            }.bind(this));
        },
        
        /**
         * closes the modal
         * @return null
         */
        closeModal: function() {
            return this.transitionToRoute('dashboard.partners.index');
        }
    },
    
    /**
     * create a temp id for uploads
     * @return string
     */
    partnerTypes: ['partner', 'sponsor'],
    
    /**
     * create a temp id for uploads
     * @return string
     */
    tempid: function() {
        return md5(moment.unix());
    }.property(),
    
    /**
     * the image uploaded
     * @return array
     */
    upload: null,
    
    /**
     * Handle file uploads by saving them to a temp array to be fixed with the 
     * event id as the key upon saving the event
     */
    handleUpload: function() {
        var upload = this.get('upload');
        if(upload === null) {
            return;
        }
        this.set('model.partner.logo_file_uuid', upload.uuid);
    }.observes('upload'),

});
