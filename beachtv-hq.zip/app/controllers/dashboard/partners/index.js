import Ember from 'ember';

export default Ember.Controller.extend({
    actions: {
        deletePartner: function(partner) {
            Ember.$('#'+partner.get('id')).css('opacity', '.7');
            partner.destroyRecord().then(function(partner) {
                Ember.$('#'+partner.get('id')).fadeOut();
            });
        }
    },
    
    /**
     * query paramets binding to controller to route
     * @return array
     */
    queryParams: ['page', 'perPage', 'searchQuery'],

    /**
     * query param bindings
     * @return various
     */
    page: 1,
    perPage: 100,
    searchQuery: '',
    
    /**
     * the max number of page per options and min
     * @return array
     */
    perPageOptions: [5, 10, 15, 20, 25, 50, 100, 200, 500, 1000, 2500, 5000],
});
