import Ember from 'ember';
import config from '../../config/environment';

export default Ember.Controller.extend({
    
    actions: {

        login: function() {
            // set default login properties
            this.setProperties({
                loginFailed: false,
                isProcessing: true
            });
            
            // check for identity
            if(!this.get('identity')) {
                this.reset('error');
                return this.get('notifications').warning('No username or email address entered.');
            }
            
            // check for identity
            if(!this.get('password')) {
                this.reset('error');
                return this.get('notifications').error('No password entered.');
            }

            // set timeout trigger
            this.set('timeout', setTimeout(this.slowConnection.bind(this), 5000));

            // start login request
            var request = Ember.$.post(config.api.url + 'auth/login', this.getProperties('identity', 'password'));
            request.then(this.success.bind(this), this.failure.bind(this));
        },
    },

    loginFailed: false,
    isProcessing: false,
    isSlowConnection: false,
    timeout: null,

    success: function(response) {
        // done 
        this.reset('success');
        this.set('isProcessing', false);
        // transition
        if(response.user.account_type == 'admin') {
            Cookies.set('userSession', response.user.uuid);
            Cookies.set('userSessionToken', md5(response.user.uuid));
            return this.transitionToRoute('dashboard.index');
        }
        return this.get('notifications').error('Authentication failed, no access permissions.');
    },

    failure: function(error) {
        if(error.responseJSON) {
            error = error.responseJSON;
        }
        this.reset('error');
        if(error.errors !== undefined) {
            this.get('notifications').error((error.errors.length) ? error.errors.join('\n') : 'Authentication failed.');
        } else {
            this.get('notifications').error('Experiencing connectivity issues.');
        }
        this.set('loginFailed', true);
    },

    slowConnection: function() {
        this.get('notifications').error('Experiencing connectivity issues.');
    },

    reset: function(type) {
        if (type === 'success') {
            this.setProperties({
                identity: null,
                password: null
            });
        }
        else if (type === 'error') {
            this.set('password', null);
        }
        clearTimeout(this.get('timeout'));
        this.setProperties({
            isProcessing: (type === 'error') ? false : true,
            isSlowConnection: false
        });
    },
    
    displayLoader: function() {
        if(this.get('isProcessing')) {
            Ember.$('#appLoader').show();
        } else {
            Ember.$('#appLoader').hide();
        }
    }.observes('isProcessing'),

});
