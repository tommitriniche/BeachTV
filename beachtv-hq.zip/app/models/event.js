import DS from 'ember-data';
import Ember from 'ember';
// import config from '../config/environment';

export default DS.Model.extend({
    uuid: DS.attr('string'),
    tempid: DS.attr('string'),
    photo_uuid: DS.attr('string'),
    photo: DS.belongsTo('file'),
    category_uuid: DS.attr('string'),
    category_name: DS.attr('string'),
    category: DS.belongsTo('category'),
    // rsvps: DS.hasMany('event-rsvp'),
    waitlist_uuid: DS.attr('string'),
    address_uuid: DS.attr('string'),
    address_name: DS.attr('string'),
    how_to_find: DS.attr('string'),
    address: DS.belongsTo('address'),
    title: DS.attr('string'),
    details: DS.attr('string'),
    start_date: DS.attr('string'),
    start_time: DS.attr('string'),
    end_date: DS.attr('string'),
    end_time: DS.attr('string'),
    repeat_interval_count: DS.attr('number'),
    repeat_interval: DS.attr('string'),
    repeat_dow: DS.attr('string'),
    repeat_frequency: DS.attr('number'),
    repeat_end: DS.attr('string'),
    charge_for_event: DS.attr('number'),
    price: DS.attr('number'),
    payment_method: DS.attr('string'),
    attendee_limit: DS.attr('number'),
    spotsOpen: DS.attr('number'),
    waitlist_enabled: DS.attr('number'),
    rsvp_start: DS.attr('string'),
    rsvp_until: DS.attr('string'),
    slug: DS.attr('string'),
    date_slug: DS.attr('string'),
    status: DS.attr('string'),
    deleted_at: DS.attr('string'),
    created_at: DS.attr('string'),
    updated_at: DS.attr('string'),

    // url: function() {
    //     return config.protocol + config.domain + '/event/' + this.get('permalink');
    // }.property('permalink'),

    canRegister: function() {
        return (this.get('spotsOpen') > 0 && this.get('onlineRegistration') === true);
    }.property('spotsOpen', 'onlineRegistration'),

    noAttendeeLimit: function() {
        return (this.get('attendee_limit') === 0);
    }.property('attendee_limit'),

    hasSpots: function() {
        if (this.get('attendee_limit') === 0) {
            return true;
        }
        return (this.get('spotsOpen') > 0);
    }.property('spotsOpen', 'attendee_limit'),

    detailsHTML: function() {
        return Ember.String.htmlSafe(this.get('details'));
    }.property('details'),

    eventDate: function() {
        return moment.unix(this.get('start_date')).format('MM/DD/YYYY');
    }.property('start_date'),

    eventDateLong: function() {
        return moment.unix(this.get('start_date')).format('dddd, MMMM Do YYYY');
    }.property('start_date'),

    createdOn: function() {
        return moment(this.get('created_at')).format('MM/DD/YYYY');
    }.property('created_at'),

    cost: function() {
        return numeral((this.get('price') / 100).toString()).format('$0,0.00');
    }.property('price'),

    /**
     * determines if event repeats
     * @return boolean
     */
    noRepeat: function() {
        return (this.get('repeat_interval') === 'none');
    }.property('repeat_interval'),

    /**
     * determines if event repeats by week
     * @return boolean
     */
    repeatByWeek: function() {
        return (this.get('repeat_interval') === 'week');
    }.property('repeat_interval'),

    /**
     * determines if event repeats by month
     * @return boolean
     */
    repeatByMonth: function() {
        return (this.get('repeat_interval') === 'month');
    }.property('repeat_interval'),

    /**
     * determines if event can be registered online
     * @return boolean
     */
    onlineRegistration: function() {
        return (this.get('payment_method') === 'ONLINE');
    }.property('payment_method')

});
