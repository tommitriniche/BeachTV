import DS from 'ember-data';

export default DS.Model.extend({
    uuid: DS.attr('string'),
    user_uuid: DS.attr('string'),
    billing_address_uuid: DS.attr('string'),
    item_uuid: DS.attr('string'),
    item_type: DS.attr('string'),
    charge_id: DS.attr('string'),
    description: DS.attr('string'),
    currency: DS.attr('string'),
    amount: DS.attr('string'),
    sale_type: DS.attr('string'),
    object_id: DS.attr('string'),
    status: DS.attr('string'),
    deleted_at: DS.attr('string'),
    created_at: DS.attr('string'),
    updated_at: DS.attr('string'),
    
    /**
     * get total cost and format
     * @return String
     */
    totalCost: function() {
        return numeral((this.get('amount') / 100).toString()).format('$0,0.00');
    }.property('amount'),
    
    createdOn: function() {
	    return moment(this.get('created_at')).format('MM/DD/YYYY');
	}.property('created_at'),
	
	createdOnLong: function() {
	    return moment(this.get('created_at')).format('MMMM Do YYYY');
	}.property('created_at')
});
