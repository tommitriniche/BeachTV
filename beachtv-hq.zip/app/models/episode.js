import Model from 'ember-data/model';
import attr from 'ember-data/attr';
// import { belongsTo, hasMany } from 'ember-data/relationships';

export default Model.extend({
    uuid: attr('string'),
    poster_uuid: attr('string'),
    poster_url: attr('string'),
    title: attr('string'),
    description: attr('string'),
    season: attr('string'),
    number: attr('string'),
    video_title: attr('string'),
    series_title: attr('string'),
    release_date: attr('string'),
    series_uuid: attr('string'),
    video_uuid: attr('string'),
    video_slug: attr('string'),
    slug: attr('string'),
    deleted_at: attr('string'),
	created_at: attr('string'),
	updated_at: attr('string'),
    
    excerpt: function() {
 		return (this.get('description.length') > 200) ? Ember.String.htmlSafe(this.get('description').substring(0, 200) + '...') : Ember.String.htmlSafe(this.get('description'));
 	}.property('description'),
    
    addedAgo: function() {
        return moment(this.get('created_at')).fromNow();
    }.property('created_at'),
    
    prettyDate: function() {
        return moment(this.get('created_at')).format('MMM Do YYYY');
    }.property('created_at')
});
