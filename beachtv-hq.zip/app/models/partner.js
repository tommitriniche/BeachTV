import DS from 'ember-data';

export default DS.Model.extend({
    uuid: DS.attr('string'),
    logo_file_uuid: DS.attr('string'),
    logo_url: DS.attr('string'),
	name: DS.attr('string'),
	description: DS.attr('string'),
	external_link: DS.attr('string'),
	type: DS.attr('string'),
	logo: DS.belongsTo('file'),
	slug: DS.attr('string'),
    deleted_at: DS.attr('string'),
	created_at: DS.attr('string'),
	updated_at: DS.attr('string'),
	
	createdOn: function() {
	    return moment(this.get('created_at')).format('MM/DD/YYYY');
	}.property('created_at')
});
