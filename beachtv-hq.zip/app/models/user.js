import Model from 'ember-data/model';
import attr from 'ember-data/attr';
// import { belongsTo, hasMany } from 'ember-data/relationships';

export default Model.extend({
    uuid: attr('string'),
    username: attr('string'),
    first_name: attr('string'),
    last_name: attr('string'),
    email: attr('string'),
    password: attr('string'),
    ip_address: attr('string'),
    phone_country_code: attr('string'),
    phone_number: attr('string'),
    slug: attr('string'),
    account_type: attr('string'),
    account_status: attr('string'),
    last_login: attr('string'),
    timezone: attr('string'),
    deleted_at: attr('string'),
	created_at: attr('string'),
	updated_at: attr('string'),
    
    fullName: function() {
 		return this.get('first_name') + ' ' + this.get('last_name');
    }.property('first_name', 'last_name'),
    
    lastLogin: function() {
        return moment.unix(this.get('last_login')).format('MMM Do YYYY');
    }.property('last_login'),
    
    memberSince: function() {
        return moment.unix(this.get('created_at')).format('MMM Do YYYY');
    }.property('created_at')
});
