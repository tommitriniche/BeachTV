import DS from 'ember-data';

export default DS.Model.extend({
    uuid: DS.attr('string'),
	name: DS.attr('string'),
	category_uuid: DS.attr('string'),
	video_uuid: DS.attr('string'),
    deleted_at: DS.attr('string'),
	created_at: DS.attr('string'),
	updated_at: DS.attr('string'),
	
	createdOn: function() {
	    return moment(this.get('created_at')).format('MM/DD/YYYY');
	}.property('created_at')
});
