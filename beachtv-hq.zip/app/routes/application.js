import Ember from 'ember';

export default Ember.Route.extend({
    actions: {
        endSession: function() {
            Cookies.expire('userSession');
            Cookies.expire('userSessionToken');
            return this.transitionTo('auth.login');
        }
    }
});
