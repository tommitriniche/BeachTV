import Ember from 'ember';

export default Ember.Route.extend({
    model: function(params) {
        return Ember.RSVP.hash({
            video: this.store.findRecord('video', params.uuid),
            categories: this.store.query('category', {cat_type: 'video'}),
            vid_cats: this.store.query('video-category', {video_uuid: params.uuid})
        });
    },
    
    setupController: function(controller, model) {
        this._super(controller, model);
        var selected = Ember.A();
        model.vid_cats.forEach(function(vidCat) {
            model.categories.forEach(function(category) {
                if(category.get('id') == vidCat.get('category_uuid')) {
                    category.set('isChecked', true);
                    selected.pushObject(category);
                }
            });
        });
        controller.set('selectedCategoriesQueue', selected);
    }
});
