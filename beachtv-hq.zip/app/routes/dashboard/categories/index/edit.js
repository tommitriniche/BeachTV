import Ember from 'ember';

export default Ember.Route.extend({
    model: function(params) {
        return Ember.RSVP.hash({
            category: this.store.findRecord('category', params.uuid),
            categories: this.store.findAll('category')
        });
    }
});
