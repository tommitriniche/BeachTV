import Ember from 'ember';

export default Ember.Route.extend({
    
    model: function() {
        return this.store.query('category', {cat_type: 'video'});
    },
    
    setupController: function(controller, model) {
        this._super(controller, model);
        this.controllerFor('dashboard.events.manage-categories').set('backLink', 'dashboard.events.index');
    }
    
});
