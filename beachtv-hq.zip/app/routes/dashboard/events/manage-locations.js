import Ember from 'ember';

export default Ember.Route.extend({
    
    controllerName: 'dashboard.events.locations',
    
    model: function() {
        return Ember.RSVP.hash({
            locations: this.store.query('address', {type: 'event_address'})
        });    
    },
    
    setupController: function(controller, model) {
        this._super(controller, model);
        this.controllerFor('dashboard.events.locations').set('backLink', 'dashboard.events.index');
    }
});
