import Ember from 'ember';

export default Ember.Route.extend({
    actions: {
        didTransition: function() {
            Ember.run.scheduleOnce('afterRender', this, function() {
                setTimeout(function() {
                    Ember.$('html, body').scrollTop(0);
                }, 100);
            });
        }
    },
    
    model: function(params) {
        return Ember.RSVP.hash({
            event: this.store.findRecord('event', params.uuid),
            categories: this.store.query('category', {cat_type: 'event'}),
            locations: this.store.query('address', {type: 'event_address'})
        });
    },
});
