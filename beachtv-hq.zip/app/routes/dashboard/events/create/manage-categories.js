import Ember from 'ember';

export default Ember.Route.extend({
    
    controllerName: 'dashboard.events.manage-categories',
    
    model: function() {
        return this.store.query('category', {cat_type: 'event'});
    },
    
    renderTemplate: function() {
        this.render('dashboard.events.manage-categories');
    },
    
    setupController: function(controller, model) {
        this._super(controller, model);
        this.controllerFor('dashboard.events.manage-categories').set('backLink', 'dashboard.events.create');
    }
});
