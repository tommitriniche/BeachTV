import Ember from 'ember';
import RouteMixin from 'ember-cli-pagination/remote/route-mixin';

export default Ember.Route.extend(RouteMixin, {
    
    queryParams: {
        searchQuery: {
            refreshModel: true
        },
        perPage: {
            refreshModel: true
        },
    },
    
    perPageParam: 'per_page',
    pageParam: 'current_page',
    totalPagesParam: 'meta.total_pages',
    
    model: function(params) {
        params.paramMapping = {
            page: 'current_page',
            perPage: 'limit'
        };
        params.order_by = 'id';
        params.order_set = 'asc';
        return Ember.RSVP.hash({
            events: this.findPaged('event', params)
        });
    },
    
    actions: {
        doSearch: function() {
            this.refresh();
        },
        
        reloadModel: function() {
            this.refresh();
        }
    }
    
});
