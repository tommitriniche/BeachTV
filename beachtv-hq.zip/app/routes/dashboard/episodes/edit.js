import Ember from 'ember';

export default Ember.Route.extend({
    model: function(params) {
        return Ember.RSVP.hash({
            episode: this.store.findRecord('episode', params.uuid),
            series: this.store.findAll('series'),
            videos: this.store.findAll('video')
        });
    }
});
