import Ember from 'ember';

export default Ember.Route.extend({
    bodyClass: 'page-login',
    
    beforeModel: function() {
        return this.transitionTo('auth.login');
    }
});
