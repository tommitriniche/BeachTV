import Ember from 'ember';
import config from './config/environment';

const Router = Ember.Router.extend({
  location: config.locationType,
  rootURL: config.rootURL
});

Router.map(function() {
  this.route('auth', {path: '/'}, function() {
    this.route('login');
  });
  this.route('dashboard', function() {
    this.route('users', function() {
      this.route('edit', {path: '/edit/:uuid'});
    });
    this.route('videos', function() {
      this.route('upload');
      this.route('edit', {path: '/edit/:uuid'});
    });
    this.route('categories', function() {
      this.route('index', {path: '/'}, function() {
        this.route('create');
        this.route('edit', {path: '/edit/:uuid'});
      });
    });
    this.route('partners', function() {
      this.route('index', {path: '/'}, function() {
        this.route('create');
        this.route('edit', {path: '/edit/:uuid'});
      });
    });
    this.route('events', function() {
      this.route('create', function() {
        this.route('manage-locations');
        this.route('manage-categories');
      });
      this.route('edit', {path: '/edit/:uuid'});

      this.route('locations', function() {
        this.route('manager');
      });
    });
    this.route('moderate');
    this.route('transactions', function() {});
    this.route('series', function() {
      this.route('create');
      this.route('edit', {path: '/edit/:uuid'});
    });
    this.route('episodes', function() {
      this.route('create');
      this.route('edit', {path: '/edit/:uuid'});
    });
    this.route('ugc', function() {
      this.route('create');
      this.route('edit');
    });
  });
});

export default Router;
