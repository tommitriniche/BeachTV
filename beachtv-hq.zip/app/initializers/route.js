import Ember from 'ember';

export function initialize() {
   Ember.Route.reopen({

      activate: function() {
         var cssClass = (this.bodyClass !== undefined) ? this.toCssClass() + ' ' + this.bodyClass : this.toCssClass();
         if (cssClass !== 'application') {
            Ember.$('body').addClass(cssClass);
         }
         // autoclear notifications
         this.get('notifications').setDefaultAutoClear(true);
         // Ember.$('.sidebar-elements > li > a.active').parent().addClass('active');
         Ember.run.scheduleOnce('afterRender', this, function() {
            window.BeachTVUI.init();
         });
      },

      deactivate: function() {
         Ember.$('body').removeClass(this.toCssClass());
         // Ember.$('.sidebar-elements > li > a.active').parent().removeClass('active');
      },

      toCssClass: function() {
         return this.routeName.replace(/\./g, '-').dasherize();
      }

   });
}

export default {
   name: 'beachtv-route',
   initialize
};
