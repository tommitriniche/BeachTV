import Ember from 'ember';

export default Ember.Component.extend({
    value: null,
    didInsertElement: function() {
        var element = $(this.$('.jq-timepicker'));
        element.timepicker();
        element.change(function() {
           this.set('value', element.val()); 
        }.bind(this));
        if(this.get('value') !== null) {
            element.val(this.get('value'));
        }
    }
});
