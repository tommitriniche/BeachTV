import Ember from 'ember';

export default Ember.Component.extend({
    classNames: ['multiselect-checkboxes'],
    attributeBindings: ['tagName', 'options', 'selection', 'labelProperty', 'inline'],
    tagName: null,
    options: null,
    selection: [],
    labelProperty: null,
    inline: false,
});