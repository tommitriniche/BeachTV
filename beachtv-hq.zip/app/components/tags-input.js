import Ember from 'ember';

export default Ember.Component.extend({
    attributeBindings: ['value', 'name', 'type', 'stringValue'],
    type: 'text',
    value: null,
    placeholder: false,
    tagName: 'input',
    stringValue: false,
    
    didInsertElement: function() {
        var input = Ember.$(this.$());
        input.tagsinput();
        input.change(function() {
            if(this.get('stringValue') === true) {
                this.set('value', input.val());
            } else {
                this.set('value', input.tagsinput('items'));
            }
        }.bind(this));
    }
});
