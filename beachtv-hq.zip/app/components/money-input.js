import Ember from 'ember';

export default Ember.Component.extend({
    
    classNames: ['money-input-element'],
    attributeBindings: ['value', 'placeholder'],
    value: null,
    placeholder: null,
    
    didInsertElement: function() {
        var element = $(this.$('.money-input'));
        if(this.get('value') !== null) {
            setTimeout(function() {
                element.focus().blur();
            }, 100);
        }
        element.maskMoney();
        element.change(function() {
            this.set('value', element.val());
        }.bind(this));
    },

});
