import Ember from 'ember';
import config from '../config/environment';

export default Ember.Component.extend({
    
    // actions: {
    //     /**
    //      * action to trigger on upload completeion
    //      * @return null
    //      */
    //     uploadCompleted: function() {
    //         this.sendAction('uploadComplete', this.get('value'));
    //     }
    // },
    
    attributeBindings: ['value'],
    uploader: null,
    buttonLabel: 'Upload a file',
    debug: false,
    multiple: false,
    path: null,
    type: 'FILE',
    key: null,
    clearOnComplete: false,
    
    value: function() {
        return (this.get('multiple')) ? Ember.A() : null;
    }.property('multiple'),
    
    didInsertElement: function() {
        var element = $(this.$('.fineUploader'));
        var uploader = element.fineUploaderS3({
            debug: this.get('debug'),
            // template: '#qq-template',
            allowMultipleItems: this.get('multiple'),
            request: {
                endpoint: 'https://' + config.s3.endpoint,
                accessKey: config.s3.accessKey
            },
            objectProperties: {
	        	key: function(file_id) {
	        		var filename = element.fineUploaderS3('getName', file_id);
	        		return this.get('path') + '/' + filename.replace(/ /g,'');
	        	}.bind(this),
	        	acl: 'public-read'
	        },
            signature: {
                endpoint: config.api.host + '/' + config.api.namespace + '/s3/signature'
            },
            uploadSuccess: {
                endpoint: config.api.host + '/' + config.api.namespace + '/files',
                params: {
                    type: this.get('type'),
                    key_uuid: this.get('key')
                }
            },
            retry: {
               enableAuto: false // defaults to false
            }
        });
        uploader.on('complete', function(event, id, fileName, response) {
            if(this.get('clearOnComplete')) {
                setTimeout(function() {
                    element.find('.qq-upload-list > li').each(function() {
                        $(this).fadeOut('slow'); 
                    });
                }, 1000);
            }
            if(this.get('multiple')) {
                var value = this.get('value');
                value.pushObject(response.file);
                this.sendAction('uploadComplete', value);
                return this.set('value', value);
            }
            this.set('value', response.file);
            this.sendAction('uploadComplete', response.file);
        }.bind(this));
        this.set('uploader', uploader);
        $('span#uploaderButtonText').text(this.get('buttonLabel'));
    }
});
