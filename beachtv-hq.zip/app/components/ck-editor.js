import Ember from 'ember';
import config from '../config/environment';

export default Ember.Component.extend({
    
    name: 'ckeditor',
    
    didInsertElement: function() {
        // CKEDITOR.plugins.addExternal('youtube', '/assets/ckeditor/youtube/');
        // CKEDITOR.plugins.addExternal('uploadcare', '/assets/ckeditor/uploadcare/');
        var editor = CKEDITOR.replace(this.get('name'), {
            basePath: config.protocol + config.domain + '/',
            customConfig: '',
            entities: false,
            basicEntities: false,
            // extraPlugins: 'youtube,uploadcare',
            toolbar: [
                {name: 'clipboard', items: ['Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo']},    
                {name: 'editing', items: ['Scayt']},    
                {name: 'links', items: ['Link', 'Unlink', 'Anchor']},    
                {name: 'insert', items: ['Uploadcare', 'Youtube', 'Table', 'HorizontalRule', 'SpecialChar']},    
                {name: 'tools', items: ['Maximize']},    
                // {name: 'document', items: ['Source']},
                '/',
                {name: 'basicstyles', items: ['Bold', 'Italic', 'Strike', '-', 'RemoveFormat']},
                {name: 'paragraph', items: ['NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote']},
                {name: 'styles', items: ['Styles', 'Format']},
            ]
        });
        editor.on('change', function(event) {
            this.set('value', event.editor.getData());
        }.bind(this));
    }
});
