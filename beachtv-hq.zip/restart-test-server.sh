sh kill-test-server.sh
sh run-test-server.sh
