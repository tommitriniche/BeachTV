fuser -n tcp -k 5577
