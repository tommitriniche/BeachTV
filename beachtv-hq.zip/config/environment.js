/* jshint node: true */

module.exports = function(environment) {
  var ENV = {
    modulePrefix: 'beachtv-hq',
    environment: environment,
    rootURL: '/',
    locationType: 'auto',
    googleFonts: [
      'Material+Icons',
      'Ubuntu:300,400,500,700'
    ],
    EmberENV: {
      FEATURES: {
        // Here you can enable experimental features on an ember canary build
        // e.g. 'with-controller': true
      }
    },
    
    protocol: 'http://',
    domain: 'hq.beachtv.com',
    
    api: {
      namespace: 'v1',
      host: null,
    },
    
    s3: {
      accessKey: 'AKIAIP5YTLKZHIJCEN3A',
      secretKey: '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',
      region: 'ap-southeast-1',
      endpoint: 's3-ap-southeast-1.amazonaws.com/beachtv/'
    },

    APP: {
      // Here you can pass flags/options to your application instance
      // when it is created
    }
  };

  if (environment === 'development') {
    // ENV.APP.LOG_RESOLVER = true;
    // ENV.APP.LOG_ACTIVE_GENERATION = true;
    // ENV.APP.LOG_TRANSITIONS = true;
    // ENV.APP.LOG_TRANSITIONS_INTERNAL = true;
    // ENV.APP.LOG_VIEW_LOOKUPS = true;
  }

  if (environment === 'test') {
    // ENV.api.namespace = 'v1';
    // ENV.api.host = 'http://beachtv-api.rarbuilt.io';
    // ENV.protocol = 'http://';
    // ENV.domain = 'beachtv-hq.rarbuilt.io';
    ENV.api.namespace = 'v1';
    ENV.api.host = 'http://api.beachtv.asia';
    ENV.protocol = 'http://';
    ENV.domain = 'beachtv.asia';
    // Testem prefers this...
    // ENV.locationType = 'none';

    // keep test console output quieter
    // ENV.APP.LOG_ACTIVE_GENERATION = false;
    // ENV.APP.LOG_VIEW_LOOKUPS = false;

    // ENV.APP.rootElement = '#ember-testing';
  }

  if (environment === 'production') {
    ENV.api.namespace = 'v1';
    ENV.api.host = 'http://api.beachtv.asia';
    ENV.protocol = 'http://';
    ENV.domain = 'beachtv.asia';
  }
  
  ENV.api.url = ENV.api.host + '/' + ENV.api.namespace + '/';

  return ENV;
};
