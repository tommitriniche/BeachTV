<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Stripe, Mailgun, SparkPost and others. This file provides a sane
    | default location for this type of information, allowing packages
    | to have a conventional place to find your various credentials.
    |
    */

    'mailgun' => [
        'domain' => env('MAILGUN_DOMAIN'),
        'secret' => env('MAILGUN_SECRET'),
    ],
    
    'mandrill' => [
        'key' => 'zmBHFWiVtCJ6QAZRof0HUg'  
    ],

    'ses' => [
        'key' => env('SES_KEY'),
        'secret' => env('SES_SECRET'),
        'region' => 'us-east-1',
    ],

    'sparkpost' => [
        'secret' => env('SPARKPOST_SECRET'),
    ],
    
    'aws' => [
        'key'    => env('AWS_KEY'),
        'secret' => env('AWS_SECRET'),
        'region' => 'ap-southeast-1',
        'version' => 'latest'
    ],
    
    's3' => [
        'bucket' => 'beachtv'  
    ],
    
    'coconut' => [
        'key'    => 'k-dea6684e5e8aad7ed87046e117489077',
    ],

    'stripe' => [
        'model'  => BeachTV\Models\User::class,
        'key'    => env('STRIPE_KEY'),
        'secret' => env('STRIPE_SECRET'),
        'percent_rate' => '2.9',
        'flat_rate' => '30'
    ],

];
