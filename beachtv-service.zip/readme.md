## ShipSwift API v1.0 Technical Specifications

* * *


This document will cover the technical specifications of the ShipSwift API service, which will detail the data models, the routes, database migration, real time server, background tasks and requirements that will power the cloud logistics platform. 

### 3rd Party API’s

##### ERP Rates

<table>
  <tr>
    <td>URL</td>
    <td>AccountKey</td>
    <td>UniqueUserID</td>
  </tr>
  <tr>
    <td>http://datamall2.mytransport.sg/ltaodataservice/ERPRates</td>
    <td>bePOWmybRhKvM3vTJB5/kQ==</td>
    <td>623c6339-fdb0-4d3a-854a-e3d0b472ddc5</td>
  </tr>
</table>


### Data Models

##### User Model

<table>
  <tr>
    <td>Column</td>
    <td>Type</td>
  </tr>
  <tr>
    <td>id</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>company_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>email</td>
    <td>string</td>
  </tr>
  <tr>
    <td>password</td>
    <td>string</td>
  </tr>
  <tr>
    <td>secret</td>
    <td>string</td>
  </tr>
  <tr>
    <td>first_name</td>
    <td>string</td>
  </tr>
  <tr>
    <td>last_name</td>
    <td>string</td>
  </tr>
  <tr>
    <td>ip_address</td>
    <td>string</td>
  </tr>
  <tr>
    <td>phone_number</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>phone_country_code</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>slug</td>
    <td>string</td>
  </tr>
  <tr>
    <td>account_type</td>
    <td>string</td>
  </tr>
  <tr>
    <td>account_status</td>
    <td>string</td>
  </tr>
</table>


##### Company Model

<table>
  <tr>
    <td>Column</td>
    <td>Type</td>
  </tr>
  <tr>
    <td>id</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>name</td>
    <td>string</td>
  </tr>
  <tr>
    <td>company_type</td>
    <td>string</td>
  </tr>
  <tr>
    <td>phone_number</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>phone_country_code</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>address_uuid</td>
    <td>String (Address Model)</td>
  </tr>
  <tr>
    <td>slug</td>
    <td>string</td>
  </tr>
</table>


##### Group Model

<table>
  <tr>
    <td>Column</td>
    <td>Type</td>
  </tr>
  <tr>
    <td>id</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>company_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>name</td>
    <td>string</td>
  </tr>
  <tr>
    <td>description</td>
    <td>text</td>
  </tr>
  <tr>
    <td>slug</td>
    <td>string</td>
  </tr>
</table>


##### App Model

<table>
  <tr>
    <td>Column</td>
    <td>Type</td>
  </tr>
  <tr>
    <td>id</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>company_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>app_id</td>
    <td>string</td>
  </tr>
  <tr>
    <td>app_type</td>
    <td>string (mobile/web)</td>
  </tr>
  <tr>
    <td>app_subdomain</td>
    <td>string</td>
  </tr>
  <tr>
    <td>app_domain</td>
    <td>string</td>
  </tr>
  <tr>
    <td>name</td>
    <td>string</td>
  </tr>
  <tr>
    <td>description</td>
    <td>text</td>
  </tr>
  <tr>
    <td>slug</td>
    <td>string</td>
  </tr>
</table>


##### Module Model

<table>
  <tr>
    <td>Column</td>
    <td>Type</td>
  </tr>
  <tr>
    <td>id</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>name</td>
    <td>string</td>
  </tr>
  <tr>
    <td>description</td>
    <td>text</td>
  </tr>
  <tr>
    <td>route</td>
    <td>string</td>
  </tr>
  <tr>
    <td>slug</td>
    <td>string</td>
  </tr>
</table>


##### Module View Model

<table>
  <tr>
    <td>Column</td>
    <td>Type</td>
  </tr>
  <tr>
    <td>id</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>module_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>name</td>
    <td>string</td>
  </tr>
  <tr>
    <td>description</td>
    <td>text</td>
  </tr>
  <tr>
    <td>route</td>
    <td>string</td>
  </tr>
  <tr>
    <td>slug</td>
    <td>string</td>
  </tr>
</table>


##### Permission Model

<table>
  <tr>
    <td>Column</td>
    <td>Type</td>
  </tr>
  <tr>
    <td>id</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>app_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>owner_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>owner_type</td>
    <td>string (user/group)</td>
  </tr>
  <tr>
    <td>permission_type</td>
    <td>string (module/view)</td>
  </tr>
  <tr>
    <td>access</td>
    <td>integer </td>
  </tr>
  <tr>
    <td>slug</td>
    <td>string</td>
  </tr>
</table>


##### Address Model

<table>
  <tr>
    <td>Column</td>
    <td>Type</td>
  </tr>
  <tr>
    <td>id</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>company_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>name</td>
    <td>string</td>
  </tr>
  <tr>
    <td>address_type</td>
    <td>string</td>
  </tr>
  <tr>
    <td>street_address1</td>
    <td>string</td>
  </tr>
  <tr>
    <td>street_address2</td>
    <td>string</td>
  </tr>
  <tr>
    <td>unit_number</td>
    <td>string</td>
  </tr>
  <tr>
    <td>postal_code</td>
    <td>string</td>
  </tr>
  <tr>
    <td>city</td>
    <td>string</td>
  </tr>
  <tr>
    <td>province</td>
    <td>string</td>
  </tr>
  <tr>
    <td>country</td>
    <td>string</td>
  </tr>
  <tr>
    <td>longitude</td>
    <td>string</td>
  </tr>
  <tr>
    <td>latitude</td>
    <td>string</td>
  </tr>
  <tr>
    <td>neighborhood</td>
    <td>string</td>
  </tr>
</table>


##### Route Model

<table>
  <tr>
    <td>Column</td>
    <td>Type</td>
  </tr>
  <tr>
    <td>id</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>company_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>name</td>
    <td>string</td>
  </tr>
  <tr>
    <td>origin_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>destination_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>order</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>slug</td>
    <td>string</td>
  </tr>
</table>


##### Trip Model

<table>
  <tr>
    <td>Column</td>
    <td>Type</td>
  </tr>
  <tr>
    <td>id</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>job_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>tracking_number</td>
    <td>string</td>
  </tr>
  <tr>
    <td>company_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>driver_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>vehicle_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>route_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>description</td>
    <td>text</td>
  </tr>
  <tr>
    <td>status</td>
    <td>string</td>
  </tr>
</table>


##### Job Model

<table>
  <tr>
    <td>Column</td>
    <td>Type</td>
  </tr>
  <tr>
    <td>id</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>company_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>name</td>
    <td>string</td>
  </tr>
  <tr>
    <td>description</td>
    <td>text</td>
  </tr>
  <tr>
    <td>slug</td>
    <td>string</td>
  </tr>
</table>


##### Waypoint Model

<table>
  <tr>
    <td>Column</td>
    <td>Type</td>
  </tr>
  <tr>
    <td>id</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>owner_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>waypoint_type</td>
    <td>string (trip/route)</td>
  </tr>
  <tr>
    <td>address_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>order</td>
    <td>integer</td>
  </tr>
</table>


##### Vehicle Model

<table>
  <tr>
    <td>Column</td>
    <td>Type</td>
  </tr>
  <tr>
    <td>id</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>company_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>vehicle_type</td>
    <td>string</td>
  </tr>
  <tr>
    <td>make</td>
    <td>string</td>
  </tr>
  <tr>
    <td>model</td>
    <td>string</td>
  </tr>
  <tr>
    <td>plate_number</td>
    <td>string</td>
  </tr>
  <tr>
    <td>vin</td>
    <td>string</td>
  </tr>
  <tr>
    <td>status</td>
    <td>string</td>
  </tr>
  <tr>
    <td>slug</td>
    <td>string</td>
  </tr>
</table>


##### Alert Model

<table>
  <tr>
    <td>Column</td>
    <td>Type</td>
  </tr>
  <tr>
    <td>id</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>company_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>to_user_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>alert_type</td>
    <td>string (warning/error/info/success)</td>
  </tr>
  <tr>
    <td>delivery_method</td>
    <td>String (email/text/voip/push)</td>
  </tr>
  <tr>
    <td>alert_message</td>
    <td>string</td>
  </tr>
  <tr>
    <td>status</td>
    <td>string</td>
  </tr>
</table>


##### Delivery Item Model

<table>
  <tr>
    <td>Column</td>
    <td>Type</td>
  </tr>
  <tr>
    <td>id</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>company_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>internal_id</td>
    <td>string</td>
  </tr>
  <tr>
    <td>name</td>
    <td>string</td>
  </tr>
  <tr>
    <td>description</td>
    <td>text</td>
  </tr>
  <tr>
    <td>item_type</td>
    <td>string</td>
  </tr>
  <tr>
    <td>weight</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>weight_unit</td>
    <td>string</td>
  </tr>
  <tr>
    <td>length</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>length_unit</td>
    <td>string</td>
  </tr>
  <tr>
    <td>width</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>width_unit</td>
    <td>string</td>
  </tr>
  <tr>
    <td>height</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>height_unit</td>
    <td>string</td>
  </tr>
  <tr>
    <td>declared_value</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>declared_value_currency</td>
    <td>string</td>
  </tr>
  <tr>
    <td>slug</td>
    <td>string</td>
  </tr>
</table>


##### File Model

<table>
  <tr>
    <td>Column</td>
    <td>Type</td>
  </tr>
  <tr>
    <td>id</td>
    <td>integer</td>
  </tr>
  <tr>
    <td>uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>company_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>uploader_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>key_uuid</td>
    <td>string</td>
  </tr>
  <tr>
    <td>caption</td>
    <td>string</td>
  </tr>
  <tr>
    <td>key</td>
    <td>string</td>
  </tr>
  <tr>
    <td>bucket</td>
    <td>string</td>
  </tr>
  <tr>
    <td>folder</td>
    <td>string</td>
  </tr>
  <tr>
    <td>etag</td>
    <td>string</td>
  </tr>
  <tr>
    <td>original_filename</td>
    <td>string</td>
  </tr>
  <tr>
    <td>type</td>
    <td>string</td>
  </tr>
  <tr>
    <td>content_type</td>
    <td>string</td>
  </tr>
  <tr>
    <td>slug</td>
    <td>string</td>
  </tr>
</table>


### Service Endpoints

The API Service can be used to access data that powers the ShipSwift cloud services. The first segment of the API will be the API version, as the cloud services grow new version may roll out. Following the version will be the endpoint of the data models the requester is seeking.

[http://api.shipswift.com/{version}/{endpoint](http://api.shipswift.com/%7Bversion%7D/%7Bendpoint)}

* /users

* /groups

* /permissions

* /apps

* /modules

* /moduleViews

* /companies

* /addresses

* /routes

* /trips

* /jobs

* /waypoints

* /vehicles

* /drivers (user alias route)

* /alerts

* /deliveryItems

* /files

#### Static Response Attributes

Static response attributes are attributes associated with data models that will always exist and be returned in the HTTP response.

<table>
  <tr>
    <td>Parameter Name</td>
    <td>Type</td>
    <td>Description</td>
  </tr>
  <tr>
    <td>created_at</td>
    <td>Unix Timestamp</td>
    <td>The date the model was created.</td>
  </tr>
  <tr>
    <td>updated_at</td>
    <td>Unix Timestamp</td>
    <td>The date the model was updated.</td>
  </tr>
  <tr>
    <td>deleted_at</td>
    <td>Unix Timestamp</td>
    <td>The date the model was deleted.</td>
  </tr>
</table>


#### Static Request Parameters

Static request parameters will be used to filter, sort, and manipulate the data returned from the API service GET request endpoints.

<table>
  <tr>
    <td>Parameter Name</td>
    <td>Type</td>
    <td>Description</td>
  </tr>
  <tr>
    <td>limit</td>
    <td>integer</td>
    <td>Limit the amount of data sets returned.</td>
  </tr>
  <tr>
    <td>current_page</td>
    <td>integer</td>
    <td>The current pagination page of data sets.</td>
  </tr>
  <tr>
    <td>order</td>
    <td>string (asc/desc)</td>
    <td>Sets the order to return the data sets.</td>
  </tr>
  <tr>
    <td>order_by</td>
    <td>string</td>
    <td>Sets the column to order the data sets by. Defaulted to created_at</td>
  </tr>
  <tr>
    <td>search_query</td>
    <td>string</td>
    <td>Query parameter to search data sets.</td>
  </tr>
  <tr>
    <td>_start_date</td>
    <td>string</td>
    <td>Offset data by the date_created.</td>
  </tr>
  <tr>
    <td>_end_date</td>
    <td>string</td>
    <td>Limit data by created_dated.</td>
  </tr>
</table>


