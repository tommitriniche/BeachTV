php artisan optimize
php artisan cache:clear
php artisan config:clear
php artisan route:cache
chmod -R 777 storage
composer dump-autoload
