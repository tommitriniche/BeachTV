<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('/', 'WelcomeController@api');
Route::group(['prefix' => 'v1', 'middleware' => [\BeachTV\Http\Middleware\RequestHeaders::class]], function() {
	
	// welcome
	Route::get('/', 'WelcomeController@api');
	
	/**
	 * All S3 requests go here
	 */
 	Route::group(['prefix' => 's3'], function() {
 		Route::post('/signature', 'S3Controller@signature');
 		Route::options('/signature', 'S3Controller@options');
 	});
	
	// auth
	Route::group(['prefix' => 'auth'], function() {
		Route::post('login', 'AuthController@login');
		Route::post('get-reset-token', 'AuthController@get_reset_token');
		Route::post('update-password', 'AuthController@update_password');
	});
	
	// api
	$restRoutes = [
		['prefix' => 'users', 'controller' => 'UserController'],	
		['prefix' => 'episodes', 'controller' => 'EpisodeController'],	
		['prefix' => 'series', 'controller' => 'SeriesController'],	
		['prefix' => 'seriesCategories', 'controller' => 'SeriesCategoryController'],	
		['prefix' => 'addresses', 'controller' => 'AddressController'],	
		['prefix' => 'files', 'controller' => 'FileController'],
		['prefix' => 'tags', 'controller' => 'TagController'],
		['prefix' => 'categories', 'controller' => 'CategoryController'],
		['prefix' => 'videos', 'controller' => 'VideoController'],
		['prefix' => 'videoViews', 'controller' => 'VideoViewController'],
		['prefix' => 'videoCategories', 'controller' => 'VideoCategoryController'],
		['prefix' => 'events', 'controller' => 'EventController'],
		['prefix' => 'eventRsvps', 'controller' => 'EventRsvpController'],
		['prefix' => 'partners', 'controller' => 'PartnerController'],
		['prefix' => 'comments', 'controller' => 'CommentController'],
		['prefix' => 'transactions', 'controller' => 'TransactionController']
	];
	foreach($restRoutes as $route) {
		Route::group(['prefix' => $route['prefix']], function() use($route) {
			if($route['prefix'] == 'videos') {
				Route::post('coconut', 'VideoController@coconutWebHook');
				Route::get('mostViewed', 'VideoController@mostViewed');
			}
			Route::get('/', $route['controller'].'@query');
			Route::get('{uuid}', $route['controller'].'@retrieve');
			Route::put('{uuid}', $route['controller'].'@update');
			Route::post('/', $route['controller'].'@create');
			Route::delete('{uuid}', $route['controller'].'@delete');
			Route::options('/', $route['controller'].'@options');
			Route::options('{uuid}', $route['controller'].'@options');
		});
	}
});
