<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEventsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('events', function (Blueprint $table) {
            $table->increments('id');
            $table->string('uuid');
            $table->string('user_uuid')->nullable();
            $table->string('category_uuid')->nullable();
            $table->string('photo_uuid')->nullable();
            $table->string('waitlist_uuid')->nullable();
            $table->string('address_uuid')->nullable();
            $table->string('title');
            $table->text('details')->nullable();
            $table->string('how_to_find')->nullable();
            $table->string('external_rsvp_url')->nullable();
            $table->integer('start_date');
            $table->string('start_time')->nullable();
            $table->integer('end_date')->nullable();
            $table->string('end_time')->nullable();
            $table->integer('repeat_interval_count')->default(0)->nullable(); // 0-12 // 0 is no repeat
            $table->string('repeat_interval')->nullable(); // week or month
            $table->text('repeat_dow')->nullable(); // day of week -- for weeks: Mon,Tue,Wed,Thu,Fri,Sat,Sun - for monthly: Mon-Sun
            $table->integer('repeat_frequency')->nullable(); // frequency for monthly: first/second/third/fourth last tuesday of every (interval_count) month
            $table->integer('charge_for_event')->default(0)->nullable();
            $table->integer('repeat_until')->nullable();
            $table->integer('price')->nullable();
            $table->string('payment_method')->default('ONLINE')->nullable(); // or OFFLINE
            $table->integer('attendee_limit')->default(0)->nullable(); // 0 = unlimited
            $table->integer('waitlist_enabled')->default(0)->nullable();
            $table->integer('rsvp_start')->nullable();
            $table->integer('rsvp_until')->nullable();
            $table->string('slug');
            $table->string('date_slug')->nullable();
            $table->string('status');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('events');
    }
}
