<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCommentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('comments', function (Blueprint $table) {
            $table->increments('id');
            $table->string('uuid');
            $table->string('user_uuid')->nullable();
            $table->string('object_uuid');
            $table->string('object_type')->nullable(); // post
            $table->string('parent_uuid')->nullable(); // post
            $table->string('order')->default('PARENT')->nullable(); // parent, child
            $table->text('content');
            $table->text('link')->nullable();
            $table->string('permalink')->nullable();
            $table->integer('views')->default(0)->nullable();
            $table->integer('notify_owner_replies')->default(0)->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('comments');
    }
}
