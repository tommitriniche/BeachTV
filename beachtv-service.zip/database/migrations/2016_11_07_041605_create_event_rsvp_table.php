<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEventRsvpTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('event_rsvp', function (Blueprint $table) {
            $table->increments('id');
            $table->string('uuid');
            $table->string('user_uuid');
            $table->integer('number_attending')->default(1)->nullable();
            $table->string('transaction_uuid')->nullable();
            $table->string('event_uuid')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('event_rsvp');
    }
}
