<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSeriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('series', function (Blueprint $table) {
            $table->increments('id');
            $table->string('uuid');
            $table->string('title')->nullable();
            $table->text('description')->nullable();
            $table->text('long_description')->nullable();
            $table->string('production_year')->nullable();
            $table->string('duration')->nullable();
            $table->string('production_house')->nullable();
            $table->string('format')->nullable();
            $table->string('broadcasters')->nullable();
            $table->string('genre')->nullable();
            $table->string('poster_uuid')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('series');
    }
}
