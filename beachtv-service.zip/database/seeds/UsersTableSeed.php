<?php

use Illuminate\Database\Seeder;
use BeachTV\Models\User;

class UsersTableSeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->delete();
		User::create([
			'username' => 'webmaster',
			'email' => 'webmaster@beachtv.asia',
			'password' => bcrypt('password'),
			'account_type' => 'admin',
			'first_name' => 'Webmaster',
			'last_name' => 'Administrator',
			'ip_address' => '127.0.0.1',
			'account_status' => 'active',
			'slug' => 'webmaster'
		]);
    }
}
