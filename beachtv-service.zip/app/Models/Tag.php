<?php

namespace BeachTV\Models;

use Illuminate\Database\Eloquent\Model;

use BeachTV\Traits\UuidTrait;

class Tag extends EmberModel
{
    use UuidTrait;
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'tags';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['uuid', 'name', 'element_id', 'element_type', 'slug'];
    
    /**
     * Search columns for tag
     * 
     * @var array
     */
    protected $searchProperties = ['name'];

}
