<?php

namespace BeachTV\Models;

use Illuminate\Database\Eloquent\Model;

use BeachTV\Traits\UuidTrait;

class VideoView extends EmberModel
{
    use UuidTrait;
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'video_views';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['uuid', 'user_uuid', 'video_uuid'];
    
    /**
     * Search columns for tag
     * 
     * @var array
     */
    protected $searchProperties = [];

}
