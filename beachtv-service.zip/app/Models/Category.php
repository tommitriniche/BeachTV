<?php

namespace BeachTV\Models;

use Illuminate\Database\Eloquent\Model;

use BeachTV\Traits\UuidTrait;

class Category extends EmberModel
{
    
    use UuidTrait;
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'categories';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['name', 'parent_cat_uuid', 'thumbnail_file_uuid', 'description', 'cat_type', 'slug'];
    
    /**
     * Search columns for tag
     * 
     * @var array
     */
    protected $searchProperties = ['name'];
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $appends = ['thumbnail_url'];
    
    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = ['thumbnail'];
    
    public function getThumbnailUrlAttribute() {
        return (isset($this->thumbnail)) ? $this->thumbnail->s3url : null;
    }
    
    public function thumbnail() {
        return $this->belongsTo('BeachTV\Models\File', 'thumbnail_file_uuid', 'uuid');
    }
    
}
