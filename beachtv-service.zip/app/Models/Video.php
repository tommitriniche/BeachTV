<?php

namespace BeachTV\Models;

use Illuminate\Database\Eloquent\Model;

use BeachTV\Traits\UuidTrait;

class Video extends EmberModel
{
    
    use UuidTrait;
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'videos';
    
    /**
     * search properties
     * 
     * @var array
     */
    protected $searchProperties = ['title', 'content', 'path'];
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['path', 'file_uuid', 'uploader_uuid', 'encoding_complete', 'title', 'content', 'meta', 'featured', 'category_uuid', 'slug', 'price'];
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $appends = ['tagList', 'mp4_url', 'webm_url', 'gif_url', 'jpg_url', 'poster_url', 'views_count', 'cat'];
    
    protected $hidden = ['views'];
    
    public function views() {
        return $this->hasMany('BeachTV\Models\VideoView', 'video_uuid', 'uuid');
    }
    
    public function getViewsCountAttribute() {
        return count($this->views);
    }
    
    public function getMetaAttribute($meta) {
        return json_decode($meta);
    }
    
    public function getS3UrlAttribute() {
        return 'https://s3-ap-southeast-1.amazonaws.com/beachtv/' . $this->path;
    }
    
    public function s3($format) {
        return 'https://s3-ap-southeast-1.amazonaws.com/beachtv/' . $this->s3_dir . $format;
    }
    
    public function getMp4UrlAttribute() {
        return $this->s3('mp4');
    }
    
    public function getWebmUrlAttribute() {
        return $this->s3('webm');
    }
    
    public function getGifUrlAttribute() {
        if(!$this->encoding_complete) {
            return 'https://s3-ap-southeast-1.amazonaws.com/beachtv/assets/video_noise.jpg';
        }
        return $this->s3('gif');
    }
    
    public function getJpgUrlAttribute() {
        return $this->s3('jpg');
    }
    
    public function getPosterUrlAttribute() {
        $path = pathinfo($this->path);
        return (isset($this->file)) ? 'https://s3-ap-southeast-1.amazonaws.com/beachtv/' . $path['dirname'] . '/' . $this->file->permalink . '/' . $this->uuid . '_poster.jpg' : null;
    }
    
    public function getS3DirAttribute() {
        $path = pathinfo($this->path);
        return (isset($this->file)) ? $path['dirname'] . '/' . $this->file->permalink . '/' . $this->uuid . '.' : '';
    }
    
    public function file() {
        return $this->belongsTo('BeachTV\Models\File', 'file_uuid', 'uuid');
    }
    
    public function tags() {
        return $this->hasMany('BeachTV\Models\Tag', 'element_id', 'uuid');
    }
    
    public function tagsToArray() {
        $arr = [];
        foreach($this->tags as $tag) {
            $arr[] = $tag->name;
        }
        return $arr;
    }
    
    public function getTagListAttribute() {
        return implode(',', $this->tagsToArray());
    }
    
    public function createTag($name) {
        if(!$name) {
            return false;
        }
        return Tag::firstOrCreate(['name' => $name, 'video_id' => $this->id, 'element_type' => 'video']);
    }
    
    public function user() {
        return $this->belongsTo('BeachTV\Models\User', 'uploader_uuid', 'uuid');
    }
    
    public function category() {
        return $this->belongsTo('BeachTV\Models\Category', 'category_uuid', 'uuid');
    }
    
    public function getCatAttribute() {
        return (isset($this->category)) ? ['name' => $this->category->name, 'slug' => $this->category->slug] : null;
    }
    
    public function getDateTimestampAttribute() {
        return strtotime($this->date);
    }
    
    public function getUsernameAttribute() {
        return (isset($this->user)) ? $this->user->username : null;
    }
}
