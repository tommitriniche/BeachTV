<?php

namespace BeachTV\Models;

use Illuminate\Database\Eloquent\Model;

use BeachTV\Traits\UuidTrait;

class SeriesCategory extends EmberModel
{
    use UuidTrait;
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'series_categories';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['uuid', 'category_uuid', 'series_uuid'];
    
    /**
     * Search columns for tag
     * 
     * @var array
     */
    protected $searchProperties = [];
    
    /**
     * Search columns for tag
     * 
     * @var array
     */
    protected $appends = ['series_title'];
    
    public function series() {
        return $this->belongsTo('BeachTV\Models\Series', 'series_uuid', 'uuid');
    }
    
    public function getSeriesTitleAttribute() {
        return (isset($this->series)) ? $this->series->title : null;
    }

}
