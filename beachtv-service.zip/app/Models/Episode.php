<?php

namespace BeachTV\Models;

use Illuminate\Database\Eloquent\Model;

use BeachTV\Traits\UuidTrait;

class Episode extends EmberModel
{
    use UuidTrait;
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'episodes';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['uuid', 'title', 'description', 'release_date', 'season', 'number', 'series_uuid', 'video_uuid', 'poster_uuid', 'slug'];
    
    /**
     * Search columns for tag
     * 
     * @var array
     */
    protected $searchProperties = ['title', 'description'];
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $appends = ['poster_url', 'series_title', 'video_title', 'video_slug'];
    
    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = ['poster', 'series', 'video'];
    
    public function getPosterUrlAttribute() {
        if(isset($this->poster)) {
            return $this->poster->s3url;
        } else if(isset($this->series)) {
            return $this->series->poster->s3url;
        }
        return null;
    }
    
    public function poster() {
        return $this->belongsTo('BeachTV\Models\File', 'poster_uuid', 'uuid');
    }
    
    public function getSeriesTitleAttribute() {
        return (isset($this->series)) ? $this->series->title : null;
    }
    
    public function series() {
        return $this->belongsTo('BeachTV\Models\Series', 'series_uuid', 'uuid');
    }
    
    public function getVideoTitleAttribute() {
        return (isset($this->video)) ? $this->video->title : null;
    }
    
    public function getVideoSlugAttribute() {
        return (isset($this->video)) ? $this->video->slug : null;
    }
    
    public function video() {
        return $this->belongsTo('BeachTV\Models\Video', 'video_uuid', 'uuid');
    }

}
