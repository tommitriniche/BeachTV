<?php

namespace BeachTV\Models;

use Illuminate\Database\Eloquent\Model;
use BeachTV\Traits\UuidTrait;
use BeachTV\Models\EmberModel;

class EventRSVP extends EmberModel
{
    use UuidTrait;
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'event_rsvp';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['user_uuid', 'transaction_uuid', 'number_attending', 'event_uuid']; // add number_attending
    
    /**
     * Dynamic attributes that are appended to object
     *
     * @var array
     */
    protected $appends = [];
}
