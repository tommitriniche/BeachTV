<?php

namespace BeachTV\Models;

use Illuminate\Database\Eloquent\Model;
use BeachTV\Traits\UuidTrait;
use BeachTV\Models\EmberModel;

class Partner extends EmberModel
{
    use UuidTrait;
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'partners';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['logo_file_uuid', 'name', 'description', 'type', 'external_link', 'slug']; // add number_attending
    
    /**
     * Dynamic attributes that are appended to object
     *
     * @var array
     */
    protected $appends = ['logo_url'];
    
    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = ['logo'];
    
    public function getLogoUrlAttribute() {
        return (isset($this->logo)) ? $this->logo->s3url : null;
    }
    
    /**
     * Get the logo assosciated if any
     * 
     * @return EmberModel
     */
    public function logo() {
        return $this->hasOne('BeachTV\Models\File', 'uuid', 'logo_file_uuid');
    }
}
