<?php

namespace BeachTV\Models;

use Illuminate\Database\Eloquent\Model;
use BeachTV\Traits\UuidTrait;
use BeachTV\Models\EmberModel;

class Comment extends EmberModel
{
    use UuidTrait;
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'comments';
    
    // /**
    //  * The slug id for comment.
    //  *
    //  * @var string
    //  */
    // protected $slugProperty = 'permalink';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['user_uuid', 'object_uuid', 'object_type', 'parent_uuid', 'order', 'content', 'link', 'views', 'notify_owner_replies']; // add number_attending
    
    /**
     * Dynamic attributes that are appended to object
     *
     * @var array
     */
    protected $appends = [];
    
    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [];
    
    public function user() {
        return $this->belongsTo('BeachTV\Models\User', 'user_uuid', 'uuid');
    }
}
