<?php

namespace BeachTV\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Foundation\Auth\Access\Authorizable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;

use BeachTV\Traits\UuidTrait;

class User extends EmberModel implements AuthenticatableContract, AuthorizableContract, CanResetPasswordContract 
{
    use Authenticatable, Authorizable, CanResetPassword, UuidTrait;
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'users';
    
    /**
     * The property to use as model slug.
     *
     * @var string
     */
    protected $slugProperty = 'username';
    
    /**
     * These attributes that can be queried
     * 
     * @var array
     */
    protected $searchProperties = ['email', 'first_name', 'last_name', 'username'];
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'first_name', 'last_name', 'avatar_uuid', 'username', 'email', 'password', 'last_login', 'ip_address', 'phone_number', 'phone_country_code', 'date_of_birth', 'slug', 'account_type', 'account_status'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token', 'secret'
    ];
    
    /**
     * Dynamic attributes that are appended to object
     *
     * @var array
     */
    protected $appends = ['avatarUrl'];
    
    public function avatar() {
        return $this->belongsTo('BeachTV\Models\File', 'avatar_uuid', 'uuid');
    }
    
    public function getAvatarUrlAttribute() {
        return (isset($this->avatar)) ? $this->avatar->s3url : 'https://s3-ap-southeast-1.amazonaws.com/beachtv/assets/avatar.png';
    }
}
