<?php

namespace BeachTV\Models;

use Illuminate\Database\Eloquent\Model;
use BeachTV\Traits\UuidTrait;
use BeachTV\Models\EmberModel;

class Event extends EmberModel
{
    use UuidTrait;
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'events';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'category_uuid', 
        'waitlist_uuid', 
        'photo_uuid',
        'title', 
        'details', 
        'address_uuid', 
        'how_to_find', 
        'start_date', 
        'start_time', 
        'end_date', 
        'end_time', 
        'repeat_interval_count', 
        'repeat_interval', 
        'repeat_dow', 
        'repeat_frequency', 
        'repeat_until', 
        'charge_for_event', 
        'price', 
        'payment_method', 
        'attendee_limit', 
        'waitlist_enabled', 
        'rsvp_start', 
        'rsvp_until', 
        'slug', 
        'date_slug', 
        'status'
    ];
    
    /**
     * Dynamic attributes that are appended to object
     *
     * @var array
     */
    protected $appends = ['spotsOpen', 'category_name', 'address_name', 'photo_url'];
    
    /**
     * Get all event rsvps
     * 
     * @return EmberModel
     */
    public function rsvps() {
        return $this->hasMany('BeachTV\Models\EventRSVP', 'event_uuid', 'uuid');
    }
    
    /**
     * Get the category assosciated if any
     * 
     * @return EmberModel
     */
    public function category() {
        return $this->hasOne('BeachTV\Models\Category', 'uuid', 'category_uuid');
    }
    
    /**
     * Get the category name assosciated if any
     * 
     * @return EmberModel
     */
    public function getCategoryNameAttribute() {
        return (isset($this->category)) ? $this->category->name : null;
    }
    
    /**
     * Get the address assosciated if any
     * 
     * @return EmberModel
     */
    public function address() {
        return $this->hasOne('BeachTV\Models\Address', 'uuid', 'address_uuid');
    }
    
    /**
     * Get the address name assosciated if any
     * 
     * @return EmberModel
     */
    public function getAddressNameAttribute() {
        return (isset($this->address)) ? $this->address->name : null;
    }
    
    /**
     * Get the photo assosciated if any
     * 
     * @return EmberModel
     */
    public function photo() {
        return $this->hasOne('BeachTV\Models\File', 'uuid', 'photo_uuid');
    }
    
    /**
     * Get the url of the photo assosciated
     * 
     * @return EmberModel
     */
    public function getPhotoUrlAttribute() {
        return (isset($this->photo)) ? $this->photo->s3url : null;
    }
    
    /**
     * Get all spots left open
     * 
     * @return EmberModel
     */
    public function getSpotsOpenAttribute() {
        if(intval($this->attendee_limit) === 0) {
            return 9999;
        }
        $rsvps = [];
        foreach($this->rsvps as $rsvp) {
            $rsvps[] = $rsvp->number_attending;
        }
        return (intval($this->attendee_limit) - array_sum($rsvps));
    }
    
}
