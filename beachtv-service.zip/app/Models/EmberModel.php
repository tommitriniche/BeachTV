<?php

namespace BeachTV\Models;

use Illuminate\Database\Eloquent\Model;
use BeachTV\Helpers\API_Helper;
use Ramsey\Uuid\Uuid;
use Ramsey\Uuid\Exception\UnsatisfiedDependencyException;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Http\Request;
use BeachTV\Helpers\Inflection_Helper;
use DB;

class EmberModel extends Model
{

    use SoftDeletes;

    /**
     * allows you to query records
     * @return Array
     */
    public function queryRecord($request = null, $with = [], $runBefore = null, $runAfter = null) {
        if($request === null) {
            $request = (new Request);
        }
        if(is_array($request)) {
            $options = $request[0];
            $request = $request[1];
        } else {
            $options = $request->all();
        }
        // do inflections
        $term = str_replace(' ', '', ucwords(str_replace('_', ' ', $this->table)));
        $pluralTerm = lcfirst(Inflection_Helper::pluralize($term));
        $singularTerm = lcfirst(Inflection_Helper::singularize($term));
        if(isset($this->pluralTerm)) {
            $pluralTerm = $this->pluralTerm;
        }
        if(isset($this->singularTerm)) {
            $singularTerm = $this->singularTerm;
        }
        if(is_callable($runBefore)) {
            $before = $runBefore($request, $options);
            if($before instanceof \Illuminate\Http\JsonResponse) {
                return $before;
            }
        }
        $meta = [];
        // pagination
        if(isset($options['current_page'])) {
            if(isset($options['per_page'])) {
                $options['limit'] = $options['per_page'];
            } else if(isset($options['limit'])) {
                $options['per_page'] = $options['limit'];
            }
            if(isset($options['per_page'])) {
                $options['offset'] = ($options['per_page']*($options['current_page']-1));
            }
            $meta['current_page'] = $options['current_page'];
        }
        $records = $this->emberQuery($options, $with, $request);
        if(is_callable($runAfter)) {
            $after = $runAfter($request, $options, $records);
            if($after instanceof \Illuminate\Http\JsonResponse) {
                return $after;
            }
        }
        if(isset($options['limit'])) {
            $meta['total_pages'] = round($this->queryTotal/$options['limit']);
        }
        $meta['total'] = count($records);
        $meta['query_total'] = $this->queryTotal;
        if(isset($options['query_record']) && $meta['total'] == 1) {
            return response()->json([
                $singularTerm => $records[0] 
            ]);
        }
        return response()->json([
            $pluralTerm => $records,
            'meta' => $meta
        ]);
    }

    /**
     * allows you to create records
     * @return EmberModel
     */
    public function createRecord($request, $runBefore = null, $runAfter = null, $insertOverwrite = []) {
        if(is_callable($runBefore)) {
            $before = $runBefore($request, $insertOverwrite);
            if($before instanceof \Illuminate\Http\JsonResponse) {
                return $before;
            }
        }
        // saved yet?
        $saved = false;
        // do inflections
        $term = str_replace(' ', '', ucwords(str_replace('_', ' ', $this->table)));
        $pluralTerm = Inflection_Helper::pluralize($term);
        $singularTerm = Inflection_Helper::singularize($term);
        $singularModel = ucfirst($singularTerm);
        $emberModel = lcfirst($singularModel);
        if(isset($this->singularTerm)) {
            $singularTerm = $this->singularTerm;
        }
        // create a instance of the model
        $model = $this;
        // create record
        $fillable = $this->fillable;
        $insert = [];
        foreach($fillable as $property) {
            $insert[$property] = $request->input("$emberModel.$property");
        }
        // if has slug create slug
        if(key_exists('slug', $insert) || key_exists('permalink', $insert)) {
            // check for custom slug property to user
            if(isset($this->slugProperty)) {
                $slugProperty = $this->slugProperty;
                if(is_array($this->slugProperty)) {
                    $slugProperty = '';
                    foreach($this->slugProperty as $property) {
                        $slugProperty .= $insert[$property] . ' ';
                    }
                    $slugProperty = substr($slugProperty, 0, -1);
                } else if($this->slugProperty === '#') {
                    $slugProperty = API_Helper::hashid(40);
                } else {
                    $slugProperty = $insert[$this->slugProperty];
                }
                $insert['slug'] = $this->generateSlug($slugProperty);
            } else if(isset($insert['name'])) {
                $insert['slug'] = $this->generateSlug($insert['name']);
            } else if(isset($insert['title'])) {
                $insert['slug'] = $this->generateSlug($insert['title']);
            }
            if(key_exists('permalink', $insert) && isset($insert['slug'])) {
                $insert['permalink'] = $insert['slug'];
                unset($insert['slug']);
            }
        }
        // create insert data
        $insert = array_merge($insert, $insertOverwrite);
        // create the record next
        try {
            $record = $model->create($insert);
        } catch(\Illuminate\Database\QueryException $e) {
            return response()->make(API_Helper::parseSqlErrorToString($e->getMessage()), 400);
        }
        // save
        try {
            $record->save();
        } catch(\Illuminate\Database\QueryException $e) {
            return response()->make(API_Helper::parseSqlErrorToString($e->getMessage()), 400);
        }
        // run this code after
        if(is_callable($runAfter)) {
            $after = $runAfter($request, $record);
            if($after instanceof \Illuminate\Http\JsonResponse) {
                return $after;
            }
        }
        // wrap it up
        if($record->save()) {
            return response()->json([
                $emberModel => $record
            ]);
        }
        return response()->make('Failed to create ' . $singularTerm, 400);
    }

    /**
     * updates a record
     * @return EmberModel
     */
    public function updateRecord($request, $runBefore = null, $runAfter = null, $updateOverwrite = []) {
        // do inflections
        $term = str_replace(' ', '', ucwords(str_replace('_', ' ', $this->table)));
        $pluralTerm = Inflection_Helper::pluralize($term);
        $singularTerm = Inflection_Helper::singularize($term);
        $singularModel = ucfirst($singularTerm);
        $emberModel = lcfirst($singularModel);
        if(isset($this->singularTerm)) {
            $singularTerm = $this->singularTerm;
        }
        // get instance of model by uuid
        $uuid = $request->input($emberModel.'.uuid');
        $query = $this->newQuery()->select('*');
        $record = $query->where('uuid', $uuid)->first();
        if(!$record && $uuid) {
            // try to get by slug
            $record = $singularModel::where('slug', $uuid)->first();
        }
        if(!$record) {
            return response()->make($singularModel.' not found.', 400);
        }
        if(is_callable($runBefore)) {
            $before = $runBefore($request, $updateOverwrite, $record);
            if($before instanceof \Illuminate\Http\JsonResponse) {
                return $before;
            }
        }
        // saved yet?
        $saved = false;
        // update record
        $fillable = $this->fillable;
        $insert = [];
        foreach($fillable as $property) {
            $insert[$property] = $request->input("$emberModel.$property");
        }
        // if has slug create slug
        if(key_exists('slug', $insert)) {
            // check for custom slug property to user
            if(isset($this->slugProperty)) {
                $slugProperty = (isset($insert[$this->slugProperty])) ? $insert[$this->slugProperty] : null;
                if(is_array($this->slugProperty)) {
                    $slugProperty = '';
                    foreach($this->slugProperty as $property) {
                        $slugProperty .= $insert[$property] . ' ';
                    }
                    $slugProperty = substr($slugProperty, 0, -1);
                }
                if($this->slugProperty !== '#') {
                    $insert['slug'] = $this->generateSlug($slugProperty);
                }
            } else if(isset($insert['name'])) {
                if($record->name !== $insert['name']) {
                    $insert['slug'] = $this->generateSlug($insert['name']);
                }
            } else if(isset($insert['title'])) {
                if($record->title !== $insert['title']) {
                    $insert['slug'] = $this->generateSlug($insert['title']);
                }
            }
        }
        // merge overwrites
        $insert = array_merge($insert, $updateOverwrite);
        // create the record next
        try {
            $record->fill($insert);
        } catch(\Illuminate\Database\QueryException $e) {
            return response()->make(API_Helper::parseSqlErrorToString($e->getMessage()), 400);
        }
        // save
        try {
            $record->save();
        } catch(\Illuminate\Database\QueryException $e) {
            return response()->make(API_Helper::parseSqlErrorToString($e->getMessage()), 400);
        }
        // run this code after
        if(is_callable($runAfter)) {
            $after = $runAfter($request, $record);
            if($after instanceof \Illuminate\Http\JsonResponse) {
                return $after;
            }
        }
        // wrap it up
        if($record->save()) {
            return response()->json([
                $emberModel => $record
            ]);
        }
        return response()->make('Failed to update ' . $singularTerm, 400);
    }

    /**
     * retreive a record
     * @return EmberModel
     */
    public function findRecord($uuid, $with = []) {
        // do inflections
        $pluralTerm = Inflection_Helper::pluralize($this->table);
        $singularTerm = Inflection_Helper::singularize($this->table);
        $singularModel = ucfirst($singularTerm);
        if(isset($this->singularTerm)) {
            $singularTerm = $this->singularTerm;
        }
        // get instance of model by uuid
        $query = $this->newQuery()->select('*');
        $record = $query->where('uuid', $uuid)->with($with)->first();
        if(!$record && in_array('slug', $this->fillable)) {
            // try to get by slug
            $query2 = $this->newQuery()->select('*');
            $record = $query2->where('slug', $uuid)->first();
        }
        if(!$record) {
            return response()->make($singularModel.' not found.', 400);
        }
        return response()->json([
            $singularTerm => $record
        ]);
    }

    /**
     * delete a record
     * @return EmberModel
     */
    public function deleteRecord($uuid, $runAfter = null) {
        // do inflections
        $pluralTerm = Inflection_Helper::pluralize($this->table);
        $singularTerm = Inflection_Helper::singularize($this->table);
        $singularModel = ucfirst($singularTerm);
        if(isset($this->singularTerm)) {
            $singularTerm = $this->singularTerm;
        }
        // get instance of model by uuid
        $query = $this->newQuery()->select('*');
        $record = $query->where('uuid', $uuid)->first();
        if(!$record && in_array('slug', $this->fillable)) {
            // try to get by slug
            $query2 = $this->newQuery()->select('*');
            $record = $query2->where('slug', $uuid)->first();
        }
        if(!$record) {
            return response()->make($singularModel.' not found.', 400);
        }
        $record->delete();
        // run this code after
        if(is_callable($runAfter)) {
            $after = $runAfter($request, $record);
            if($after instanceof \Illuminate\Http\JsonResponse) {
                return $after;
            }
        }
        return response()->json([
            $singularTerm => $record
        ]);
    }
    
    /**
     * returns a new instance of query builder for the model
     * @return Query/Builder
     */
    public function _query($select = '*') {
        return $this->newQuery()->select(DB::raw($select));
    }

    /**
     * takes request params and queries content
     * as ember standards
     * @return array
     */
    public function emberQuery($options = array(), $with = array(), Request $request) {
        // query builder to get results with options
        $time_start = microtime(true); 
        // get and set info about table workign on
        $term = str_replace(' ', '', ucwords(str_replace('_', ' ', $this->table)));
        $pluralTerm = lcfirst(Inflection_Helper::pluralize($term));
        if(isset($this->pluralTerm)) {
            $pluralTerm = $this->pluralTerm;
        }
        if(isset($this->singularTerm)) {
            $singularTerm = $this->singularTerm;
        } else {
            $singularTerm = Inflection_Helper::singularize(strtolower($term));
        }
        // start query
        $query = $this->newQuery()->select('*');
        if(!empty($with)) {
            foreach($with as $property) {
                $query->with($property);
            }
        }
        $limit = null;
        $offset = null;
        $orderBy = 'id';
        $orderSet = 'desc';
        $searchQuery = null;
        if(isset($options['searchQuery'])) {
            $searchQuery = $options['searchQuery'];
        }
        if(isset($options['order_by'])) {
            $orderBy = $options['order_by'];
        }
        if(isset($options['order_set'])) {
            $orderSet = $options['order_set'];
        }
        if(isset($options['limit'])) {
            $limit = $options['limit'];
        }
        if(isset($options['offset'])) {
            $offset = $options['offset'];
        }
        if(isset($options['_start_date']) && $options['_start_date'] != null) {
            $_start_date = $options['_start_date'];
        }
        if(!empty($_start_date) && isset($options['_end_date']) && $options['_end_date'] != null) {
            $_end_date = $options['_end_date'];
        }
        unset($options['query_record'], $options['_start_date'], $options['_end_date'], $options['_'], $options['limit'], $options['offset'], $options['current_page'], $options['per_page'], $options['order_by'], $options['order_set'], $options['searchQuery']);
        // check options for operator values
        foreach($options as $field => $value) {
            if(strpos($value, ',') !== false) {
                list($operator, $val) = explode(',', $value);
                $options[$field] = [$operator, $value];
            }
        }
        if($searchQuery !== null && $searchQuery !== '' && count($this->searchProperties)) {
            foreach($this->searchProperties as $index => $searchColumn) {
                if($index === 0) {
                    $query->where(function($query) use ($searchColumn, $searchQuery, $options) {
                        foreach($options as $field => $value) {
                            if(is_array($value)) {
                                list($operator, $val) = $value;
                                $query->where($field, $operator, $val);
                            } else {
                                if($value == 'null') {
                                    $query->whereNull($field);
                                } else {
                                    $query->where($field, $value);
                                }
                            }
                        }
                        $query->where($searchColumn, 'LIKE', "%$searchQuery%");
                     });
                } else {
                    $query->orWhere(function($query) use ($searchColumn, $searchQuery, $options) {
                        foreach($options as $field => $value) {
                            if(is_array($value)) {
                                list($operator, $val) = $value;
                                $query->where($field, $operator, $val);
                            } else {
                                if($value == 'null') {
                                    $query->whereNull($field);
                                } else {
                                    $query->where($field, $value);
                                }
                            }
                        }
                        $query->where($searchColumn, 'LIKE', "%$searchQuery%");
                    });
                }
            }
            if(isset($this->alsoSearch) && is_array($this->alsoSearch) && count($this->alsoSearch)) {
                foreach($this->alsoSearch as $index => $relationship) {
                    $table = key($relationship);
                    $column = $relationship[$table];
                    $query->orWhereHas($table, function ($query) use ($searchQuery, $column) {
                        if(is_array($column)) {
                            $sub_table = key($column);
                            $sub_column = $column[$sub_table];
                            $query->whereHas($sub_table, function ($query) use ($searchQuery, $sub_column) {
                                $query->where($sub_column, 'LIKE', "%$searchQuery%");
                            });
                        } else {
                            $query->where($column, 'LIKE', "%$searchQuery%");
                        }
                    });
                }
            }
        } elseif($searchQuery !== null && $searchQuery !== '' && isset($this->alsoSearch) && is_array($this->alsoSearch) && count($this->alsoSearch)) {
            foreach($this->alsoSearch as $index => $relationship) {
                $table = key($relationship);
                $column = $relationship[$table];
                if($index === 0) {
                    $query->whereHas($table, function ($query) use ($searchQuery, $column) {
                        if(is_array($column)) {
                            $sub_table = key($column);
                            $sub_column = $column[$sub_table];
                            $query->whereHas($sub_table, function ($query) use ($searchQuery, $sub_column) {
                                $query->where($sub_column, 'LIKE', "%$searchQuery%");
                            });
                        } else {
                            $query->where($column, 'LIKE', "%$searchQuery%");
                        }
                    });
                } else {
                    $query->orWhereHas($table, function ($query) use ($searchQuery, $column) {
                        if(is_array($column)) {
                            $sub_table = key($column);
                            $sub_column = $column[$sub_table];
                            $query->whereHas($sub_table, function ($query) use ($searchQuery, $sub_column) {
                                $query->where($sub_column, 'LIKE', "%$searchQuery%");
                            });
                        } else {
                            $query->where($column, 'LIKE', "%$searchQuery%");
                        }
                    });
                }
            }
        } else {
            if(count($options)) {
                foreach($options as $field => $value) {
                    if(is_array($value)) {
                        list($operator, $val) = $value;
                        $query->where($field, $operator, $val);
                    } else {
                        if($value == 'null') {
                            $query->whereNull($field);
                        } else {
                            $query->where($field, $value);
                        }
                    }
                }
            }
        }
        if(!empty($_start_date) && !empty($_end_date)) {
            $query->whereBetween(DB::raw('unix_timestamp(created_at)'), [strtotime($_start_date), strtotime($_end_date)]);
        } else if(!empty($_start_date)) {
            $query->whereBetween(DB::raw('unix_timestamp(created_at)'), [strtotime($_start_date), time()]);
        }
        $this->queryTotal = $query->count();
        if($orderBy) {
            $query->orderBy($orderBy, $orderSet);
        }
        if($limit && $limit !== 'All') {
            $query->limit($limit);
        }
        if($offset) {
            $query->offset($offset);
        }
        // echo $this->generateSql($query);
        // $time_end = microtime(true);
        // //dividing with 60 will give the execution time in minutes other wise seconds
        // $execution_time = ($time_end - $time_start);
        // //execution time of the script
        // echo '<br><br><b>Total Execution Time:</b> '.$execution_time.' Seconds';
        // exit;
        return $query->get();
    }
    
    public function generateSql($query) {
        return vsprintf(str_replace('?', '"%s"', $query->toSql()), $query->getBindings());
    }

    public function emberGet($with = array(), $options = array()) {
        foreach($with as $property) {
            $this->with($property);
        }
        foreach($options as $field => $value) {
            $query->where($field, $value);
        }
        return $query->first();
    }

    public function toObject() {
        $json = $this->toJson();
        return json_decode($json);
    }

    /**
     * generates a slug on the record
     * @return string
     */
    public function generatePermalink($string, $specifyField = 'permalink', $setSlug = true) {
        return $this->generateSlug($string, $specifyField, $setSlug);
    }
     
    public function generateSlug($string, $specifyField = 'slug', $setSlug = true) {
        $initialSlug = API_Helper::slugify($string);
        $countToAppend = $this->newQuery()->select('*')->where($specifyField, $initialSlug)->count();
        $toAppend = ($countToAppend) ? ($countToAppend+1) : '';
        if($setSlug) {
            $this->{$specifyField} = $initialSlug . $toAppend;
        }
        return $this->{$specifyField};
    }

    /**
     * generates a uuid
     * @return string
     */
    public static function generateUuid() {
        $uuid = Uuid::uuid4()->__toString();
        $object = self::where('uuid', $uuid)->first();
        while(is_object($object) && $uuid == $object->uuid) {
            $uuid = Uuid::uuid4()->__toString();
        }
        return $uuid;
    }
}
