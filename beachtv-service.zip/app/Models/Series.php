<?php

namespace BeachTV\Models;

use Illuminate\Database\Eloquent\Model;

use BeachTV\Traits\UuidTrait;

class Series extends EmberModel
{
    use UuidTrait;
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'series';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['uuid', 'poster_uuid', 'category_uuid', 'title', 'description', 'long_description', 'production_year', 'duration', 'production_house', 'format', 'broadcasters', 'genre', 'slug'];
    
    /**
     * Search columns for tag
     * 
     * @var array
     */
    protected $searchProperties = ['title', 'description'];
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $appends = ['poster_url'];
    
    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = ['poster'];
    
    public function getPosterUrlAttribute() {
        return (isset($this->poster)) ? $this->poster->s3url : null;
    }
    
    public function poster() {
        return $this->belongsTo('BeachTV\Models\File', 'poster_uuid', 'uuid');
    }

}
