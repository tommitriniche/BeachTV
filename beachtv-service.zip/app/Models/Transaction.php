<?php

namespace BeachTV;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    //
}
