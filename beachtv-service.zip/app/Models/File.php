<?php

namespace BeachTV\Models;

use Illuminate\Database\Eloquent\Model;
use BeachTV\Traits\UuidTrait;
use BeachTV\Models\EmberModel;

class File extends EmberModel
{
    use UuidTrait;
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'files';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['uploader_uuid', 'key_uuid', 'key', 'bucket', 'folder', 'etag', 'original_filename', 'type', 'content_type', 'permalink', 'caption'];
    
    /**
     * Dynamic attributes that are appended to object
     *
     * @var array
     */
    protected $appends = ['s3url'];
    
    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [];
    
    /**
     * get the s3 url
     * 
     * @return string
     */
    public function gets3urlAttribute() {
        // return 'https://s3-us-west-2.amazonaws.com/' . $this->bucket . '/' . $this->key;
        // return 'https://d2ccw6qolo4k7n.cloudfront.net/' . $this->key;
        return 'https://s3-ap-southeast-1.amazonaws.com/beachtv/' . $this->key;
    }
}
