<?php 
namespace BeachTV\Helpers;

class S3_Helper {
	
	public static function signature($request) {
        return self::signPolicy($request);
	}

	private static function signPolicy($policy) {
	    if (self::isPolicyValid($policy)) {
	    	$encodePolicy = base64_encode(json_encode($policy));
	        return array(
	        	'policy' => $encodePolicy, 
	        	'signature' => self::sign($encodePolicy)
        	);
	    } else {
	        return array('invalid' => true);
	    }
	}

	private static function isPolicyValid($policy) {
		$bucketName = null;
		foreach($policy['conditions'] as $index => $condition) {
			if(key($condition) == 'bucket') {
				$bucketName = $condition[key($condition)];
				break;
			}
		}
	    return $bucketName == config('services.s3.bucket');
	}

	private static function sign($policy) {
        $clientPrivateKey = config('services.aws.secret');
	    return base64_encode(hash_hmac(
            'sha1',
            $policy,
            $clientPrivateKey,
            true
        ));
	}
}