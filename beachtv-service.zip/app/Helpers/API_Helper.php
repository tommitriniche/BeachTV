<?php 
namespace BeachTV\Helpers;

use Cocur\Slugify\Slugify;
use Hashids;
use Mandrill;

class API_Helper {
	
	public static function generateSql($query) {
        return vsprintf(str_replace('?', '"%s"', $query->toSql()), $query->getBindings());
    }
	
	public static function hashid($int = 28) {
		$integers = func_get_args();
		$hashids = new Hashids\Hashids(md5(time()));
		return $hashids->encode($int, rand(1,5), rand(5,12));
	}
	
	public static function slugify($string, $seperator = '-') {
		$slugify = new Slugify();
		return $slugify->slugify($string, $seperator);
	}
	
	public static function calculateAge($timestamp = 0, $now = 0) {
	    # default to current time when $now not given
	    if ($now == 0)
	        $now = time();
	 
	    # calculate differences between timestamp and current Y/m/d
	    $yearDiff   = date("Y", $now) - date("Y", $timestamp);
	    $monthDiff  = date("m", $now) - date("m", $timestamp);
	    $dayDiff    = date("d", $now) - date("d", $timestamp);
	 
	    # check if we already had our birthday
	    if ($monthDiff < 0)
	        $yearDiff--;
	    elseif (($monthDiff == 0) && ($dayDiff < 0))
	        $yearDiff--;
	 
	    # set the result: age in years
	    $result = intval($yearDiff);
	 
	    # deliver the result
	    return $result;
	}

	public static function parseSqlErrorToString($error) {
		$error = explode(']:', $error);
		$error = explode('(', $error[1]);
		return $error[0];
	}
	
	public static function send_email($to, $subject, $content) {
		$message = [
			'html' => $content,
			'subject' => $subject,
			'to' => [['email' => $to, 'type' => 'to']],
			'from_email' => 'hello@beachtv.asia',
			'from_name' => 'BeachTV',
			'track_opens' => true,
			'track_clicks' => true
		];
		$mandrill = new Mandrill(config('services.mandrill.key'));
		return $mandrill->messages->send($message);
	}
	
	public static function is_uuid($uuid) {
		if (!is_string($uuid) || (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/', $uuid) !== 1)) {
		    return false;
		}
		return true;
	}
}