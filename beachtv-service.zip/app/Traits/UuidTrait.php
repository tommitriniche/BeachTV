<?php 

namespace BeachTV\Traits;

use Ramsey\Uuid\Uuid;
use Ramsey\Uuid\Exception\UnsatisfiedDependencyException;

trait UuidTrait
{
    /**
     * Boot the Uuid trait for the model.
     *
     * @return void
     */
    public static function bootUuidTrait()
    {
        static::creating(function($model) {
            $uuid = Uuid::uuid4()->__toString();
            $object = $model::where('uuid', $uuid)->first();
            while(is_object($object) && $uuid == $object->uuid) {
                $uuid = Uuid::uuid4()->__toString();
            }
            $model->uuid = $uuid;
        });
    }
}