<?php

namespace BeachTV\Http\Controllers;

use Illuminate\Http\Request;

use BeachTV\Http\Requests;
use BeachTV\Models\Category;
use BeachTV\Helpers\API_Helper;

class CategoryController extends Controller
{
    /**
     * Query all Categorys
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function query(Request $request)
    {
        // if need to get the parent cat by slug
        if(!API_Helper::is_uuid($request->input('parent_cat_uuid'))) {
            // get the video uuid from slug
            $parent_cat = Category::where('slug', $request->input('parent_cat_uuid'))->first();
            if($parent_cat) {
                $_REQUEST['parent_cat_uuid'] = $parent_cat->uuid;
            }
        }
		return (new Category)->queryRecord([$_REQUEST, $request]);
    }
    
    /**
     * Create a new Category
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return (new Category)->createRecord($request);
    }
    
    /**
     * Update the Category
     *
     * @param String $uuid
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        return (new Category)->updateRecord($request);
    }

    /**
     * Find a new Category
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function retrieve($uuid)
    {
        return (new Category)->findRecord($uuid);
    }
    
    /**
     * Delete a record
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function delete($uuid) 
    {
        return (new Category)->deleteRecord($uuid);
    }
    
    /**
     * Options for Category requests
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function options() 
    {
        return response()->json([]);
    }
}
