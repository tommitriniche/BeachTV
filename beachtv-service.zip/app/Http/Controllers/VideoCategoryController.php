<?php

namespace BeachTV\Http\Controllers;

use Illuminate\Http\Request;

use BeachTV\Http\Requests;
use BeachTV\Models\VideoCategory;

class VideoCategoryController extends Controller
{
    /**
     * Query all VideoCategorys
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function query(Request $request)
    {
		return (new VideoCategory)->queryRecord($request);
    }
    
    /**
     * Create a new VideoCategory
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return (new VideoCategory)->createRecord($request);
    }
    
    /**
     * Update the VideoCategory
     *
     * @param String $uuid
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        return (new VideoCategory)->updateRecord($request);
    }

    /**
     * Find a new VideoCategory
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function retrieve($uuid)
    {
        return (new VideoCategory)->findRecord($uuid);
    }
    
    /**
     * Delete a record
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function delete($uuid) {
        return (new VideoCategory)->deleteRecord($uuid);
    }
    
    /**
     * Options for VideoCategory requests
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function options() {
        return response()->json([]);
    }
}
