<?php

namespace BeachTV\Http\Controllers;

use Illuminate\Http\Request;

use BeachTV\Http\Requests;
use BeachTV\Models\Series;
use BeachTV\Models\SeriesCategory;
use BeachTV\Models\Category;
use BeachTV\Helpers\API_Helper;

class SeriesController extends Controller
{
    /**
     * Query all Seriess
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function query(Request $request)
    {
        // if need to get the parent cat by slug
        if(isset($_REQUEST['category_uuid']) && !API_Helper::is_uuid($_REQUEST['category_uuid'])) {
            // get the video uuid from slug
            $cat = Category::where('slug', $_REQUEST['category_uuid'])->first();
            if($cat) {
                $_REQUEST['category_uuid'] = $cat->uuid;
            }
        }
		return (new Series)->queryRecord([$_REQUEST, $request]);
    }
    
    /**
     * Create a new Series
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return (new Series)->createRecord($request);
    }
    
    /**
     * Update the Series
     *
     * @param String $uuid
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        return (new Series)->updateRecord($request, function(&$request, &$overwrite, &$record) {
            if(isset($_REQUEST['series.tagList'])) {
                $tags = explode(',', $request->input('series.tagList'));
                foreach($tags as $tag) {
                    if(trim($tag)) {
                        $tag = Tag::firstOrCreate([
                            'name' => trim($tag),
                            'element_id' => $record->uuid,
                            'element_type' => 'series',
                            'slug' => API_Helper::slugify(trim($tag))
                        ]);
                        if(!$tag->uuid) {
                            $tag->uuid = Tag::generateUuid();
                            $tag->save();
                        }
                    }
                }
            }
            // delete additional categories
            SeriesCategory::where('series_uuid', $record->uuid)->delete();
            // update permalink if diff
            $title = $request->input('series.title');
            if($title !== $record->title || !$record->slug) {
                $overwrite['slug'] = API_Helper::slugify($title);
            }
        });
    }

    /**
     * Find a new Series
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function retrieve($uuid)
    {
        return (new Series)->findRecord($uuid);
    }
    
    /**
     * Delete a record
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function delete($uuid) {
        return (new Series)->deleteRecord($uuid);
    }
    
    /**
     * Options for Series requests
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function options() {
        return response()->json([]);
    }
}
