<?php

namespace BeachTV\Http\Controllers;

use Illuminate\Http\Request;

use BeachTV\Http\Requests;
use BeachTV\Models\EventRSVP;

class EventRSVPRsvpController extends Controller
{
    /**
     * Query all EventRSVPs
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function query(Request $request)
    {
		return (new EventRSVP)->queryRecord($request);
    }
    
    /**
     * Create a new EventRSVP
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return (new EventRSVP)->createRecord($request);
    }
    
    /**
     * Update the EventRSVP
     *
     * @param String $uuid
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        return (new EventRSVP)->updateRecord($request);
    }

    /**
     * Find a new EventRSVP
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function retrieve($uuid)
    {
        return (new EventRSVP)->findRecord($uuid);
    }
    
    /**
     * Delete a record
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function delete($uuid) 
    {
        return (new EventRSVP)->deleteRecord($uuid);
    }
    
    /**
     * Options for EventRSVP requests
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function options() 
    {
        return response()->json([]);
    }
}
