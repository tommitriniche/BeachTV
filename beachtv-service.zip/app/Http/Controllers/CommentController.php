<?php

namespace BeachTV\Http\Controllers;

use Illuminate\Http\Request;

use BeachTV\Http\Requests;
use BeachTV\Models\Comment;
use BeachTV\Models\Video;
use BeachTV\Helpers\API_Helper;

class CommentController extends Controller
{
    /**
     * Query all Comments
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function query(Request $request)
    {
        if(!API_Helper::is_uuid($request->input('object_uuid')) && $request->input('object_type') == 'video') {
            // get the video uuid from slug
            $video = Video::where('slug', $request->input('object_uuid'))->first();
            if($video) {
                $_REQUEST['object_uuid'] = $video->uuid;
            }
        }
		return (new Comment)->queryRecord([$_REQUEST, $request]);
    }
    
    /**
     * Create a new Comment
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return (new Comment)->createRecord($request);
    }
    
    /**
     * Update the Comment
     *
     * @param String $uuid
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        return (new Comment)->updateRecord($request);
    }

    /**
     * Find a new Comment
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function retrieve($uuid)
    {
        return (new Comment)->findRecord($uuid);
    }
    
    /**
     * Delete a record
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function delete($uuid) 
    {
        return (new Comment)->deleteRecord($uuid);
    }
    
    /**
     * Options for Comment requests
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function options() 
    {
        return response()->json([]);
    }
}
