<?php

namespace BeachTV\Http\Controllers;

use Illuminate\Http\Request;

use BeachTV\Http\Requests;
use BeachTV\Models\Episode;
use BeachTV\Models\Series;
// use BeachTV\Models\EpisodeCategory;
use BeachTV\Helpers\API_Helper;

class EpisodeController extends Controller
{
    /**
     * Query all Episodes
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function query(Request $request)
    {
        // if need to get the parent cat by slug
        if(isset($_REQUEST['series_uuid']) && !API_Helper::is_uuid($_REQUEST['series_uuid'])) {
            // get the video uuid from slug
            $series = Series::where('slug', $_REQUEST['series_uuid'])->first();
            if($series) {
                $_REQUEST['series_uuid'] = $series->uuid;
            }
        }
		return (new Episode)->queryRecord([$_REQUEST, $request]);
    }
    
    /**
     * Create a new Episode
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return (new Episode)->createRecord($request);
    }
    
    /**
     * Update the Episode
     *
     * @param String $uuid
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        return (new Episode)->updateRecord($request, function(&$request, &$overwrite, &$record) {
            if(isset($_REQUEST['episode.tagList'])) {
                $tags = explode(',', $request->input('episode.tagList'));
                foreach($tags as $tag) {
                    if(trim($tag)) {
                        $tag = Tag::firstOrCreate([
                            'name' => trim($tag),
                            'element_id' => $record->uuid,
                            'element_type' => 'episode',
                            'slug' => API_Helper::slugify(trim($tag))
                        ]);
                        if(!$tag->uuid) {
                            $tag->uuid = Tag::generateUuid();
                            $tag->save();
                        }
                    }
                }
            }
            // delete additional categories
            // EpisodeCategory::where('series_uuid', $record->uuid)->delete();
            // update permalink if diff
            $title = $request->input('episode.title');
            if($title !== $record->title || !$record->slug) {
                $overwrite['slug'] = API_Helper::slugify($title);
            }
        });
    }

    /**
     * Find a new Episode
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function retrieve($uuid)
    {
        return (new Episode)->findRecord($uuid);
    }
    
    /**
     * Delete a record
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function delete($uuid) {
        return (new Episode)->deleteRecord($uuid);
    }
    
    /**
     * Options for Episode requests
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function options() {
        return response()->json([]);
    }
}
