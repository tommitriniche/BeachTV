<?php

namespace BeachTV\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use BeachTV\Http\Requests;
use BeachTV\Http\Controllers\Controller;
use BeachTV\Models\User;
use BeachTV\Models\SetPasswordToken;
use BeachTV\Helpers\API_Helper;

class AuthController extends Controller
{
    /**
     * Takes a request username/ or email and password and attempts to authenticate user
     * will return the user model if the authentication was successful, else will 400
     *
     * @return \Illuminate\Http\Response
     */
    public function login(Request $request)
    {
        
        $identity = strtolower($request->input('identity'));
        $password = $request->input('password');

        if(!$identity) {
            return response()->json([
                'errors' => ['No email or username provided.']
            ], 400);
        }

        if(!$password) {
            return response()->json([
                'errors' => ['No password provided.']
            ], 400);
        }

        // attempt to find user by username or email
        $user = User::where('username', $identity)->orWhere('email', $identity)->first();
        if(!$user) {
            return response()->json([
                'errors' => [(strstr($identity, '@') === false) ? 'No user found with the username provided.' : 'No user found with the email provided.']
            ], 400);
        }

        // attempt to authenticate
        if(Auth::attempt(['email' => $identity, 'password' => $password]) || Auth::attempt(['username' => $identity, 'password' => $password])) {
        	// update ip address and last login
        	$user->last_login = time();
        	$user->ip_address = $request->ip();
        	$user->save();
            // done!
            return response()->json([
                'user' => $user
            ]);
        } else {
            return response()->json([
                'errors' => ['Authentication failed.']
            ], 400);
        }
    }
    
    /**
     * Create a password reset token and send it to the user
     *
     * @return \Illuminate\Http\Response
     */
    public function get_reset_token(Request $request)
    {
        $emailAddress = $request->input('email');
        $ipAddress = $request->ip();
        
        // needs a valid email address
		if(!$emailAddress) {
			return response()->json([
				'errors' => ['No email address provided.']	
			], 400);
		}
		
		// check for user
		$user = User::where('email', $emailAddress)->first();
		if(!$user) {
			return response()->json([
				'errors' => ['No account found with provided email address.']
			], 400);
		}
		
		// create a token
		$token = API_Helper::hashid(time());
		
		// create a token in the db
		$newToken = SetPasswordToken::create([
		    'user_uuid' => $user->uuid,
		    'ip_address' => $ipAddress,
		    'token' => $token,
		    'status' => 'active',
		    'expires_at' => strtotime('+15 minutes')
	    ]);
	    
	    // save and send the user an email
	    if($newToken->save()) {
	        // should send an email here
	        // done
	        if($sent) {
    	        return response()->json([
    				'token' => $newToken	
    			]);
	        } else {
	            return response()->json([
    				'errors' => ['Reset email failed to send.']	
    			], 400);
	        }
	    }
	    // fail?
	    return response()->json([
			'errors' => ['Token failed to generate.']	
		], 400);
    }
    
    /**
	 * Update the password for the user
	 *
     * @return \Illuminate\Http\Response
     */
	public function update_password(Request $request)
    {
		$token = SetPasswordToken::where('token', $request->input('token'))->first();
		if(!$token) {
			return response()->json([
				'errors' => ['Invalid token provided.']	
			], 400);
		}
		// make sure token hasn't expired
		if(time() > $token->expires_at) {
		    return response()->json([
				'errors' => ['Password reset token provided has expired.']	
			], 400);
		}
		$user = User::where('uuid', $token->user_uuid)->first();
		$user->updatePassword($request->input('new_password'));
		return response()->json([
			'user' => $user	
		]);
	}

}
