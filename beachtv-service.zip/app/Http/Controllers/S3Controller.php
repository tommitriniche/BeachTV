<?php

namespace BeachTV\Http\Controllers;

use Illuminate\Http\Request;

use BeachTV\Http\Requests;
use BeachTV\Http\Controllers\Controller;
use BeachTV\Helpers\S3_Helper;

class S3Controller extends Controller
{
    /**
     * Get a signature for S3
     *
     * @return \Illuminate\Http\Response
     */
    public function signature()
    {
        // get request
		$request = json_decode(file_get_contents('php://input'), true);
	    // get signature
	    $signature = S3_Helper::signature($request);
	    // send
		return response()->json($signature);
    }
    
    /**
     * Options for s3 requests
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function options() {
        return response()->json([]);
    }

}
