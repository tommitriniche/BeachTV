<?php

namespace BeachTV\Http\Controllers;

use Illuminate\Http\Request;

use BeachTV\Http\Requests;
use BeachTV\Models\VideoView;

class VideoViewController extends Controller
{
    /**
     * Query all VideoViews
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function query(Request $request)
    {
		return (new VideoView)->queryRecord($request);
    }
    
    /**
     * Create a new VideoView
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return (new VideoView)->createRecord($request);
    }
    
    /**
     * Update the VideoView
     *
     * @param String $uuid
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        return (new VideoView)->updateRecord($request);
    }

    /**
     * Find a new VideoView
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function retrieve($uuid)
    {
        return (new VideoView)->findRecord($uuid);
    }
    
    /**
     * Delete a record
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function delete($uuid) {
        return (new VideoView)->deleteRecord($uuid);
    }
    
    /**
     * Options for VideoView requests
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function options() {
        return response()->json([]);
    }
}
