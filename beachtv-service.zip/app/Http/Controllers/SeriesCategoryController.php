<?php

namespace BeachTV\Http\Controllers;

use Illuminate\Http\Request;

use BeachTV\Http\Requests;
use BeachTV\Models\SeriesCategory;
use BeachTV\Models\Category;
use BeachTV\Helpers\API_Helper;

class SeriesCategoryController extends Controller
{
    /**
     * Query all SeriesCategorys
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function query(Request $request)
    {
        // if need to get the parent cat by slug
        if(isset($_REQUEST['category_uuid']) && !API_Helper::is_uuid($_REQUEST['category_uuid'])) {
            // get the video uuid from slug
            $cat = Category::where('slug', $_REQUEST['category_uuid'])->first();
            if($cat) {
                $_REQUEST['category_uuid'] = $cat->uuid;
            }
        }
		return (new SeriesCategory)->queryRecord([$_REQUEST, $request]);
    }
    
    /**
     * Create a new SeriesCategory
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return (new SeriesCategory)->createRecord($request);
    }
    
    /**
     * Update the SeriesCategory
     *
     * @param String $uuid
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        return (new SeriesCategory)->updateRecord($request);
    }

    /**
     * Find a new SeriesCategory
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function retrieve($uuid)
    {
        return (new SeriesCategory)->findRecord($uuid);
    }
    
    /**
     * Delete a record
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function delete($uuid) {
        return (new SeriesCategory)->deleteRecord($uuid);
    }
    
    /**
     * Options for SeriesCategory requests
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function options() {
        return response()->json([]);
    }
}
