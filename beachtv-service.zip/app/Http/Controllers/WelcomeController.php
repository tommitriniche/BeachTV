<?php

namespace BeachTV\Http\Controllers;

use Illuminate\Http\Request;

use BeachTV\Http\Requests;

class WelcomeController extends Controller
{
    /**
     * This is the entry point for the ShipSwift API Service
     * 
     * @return Illuminate\Http\Request;
     */
    public function api() {
        return response()->json([
            'status' => 'OK',
            'message' => 'BeachTV API Service',
            'version' => config('app.version')
        ]);
    }
}
