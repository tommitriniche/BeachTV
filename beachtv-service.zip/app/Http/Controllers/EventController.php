<?php

namespace BeachTV\Http\Controllers;

use Illuminate\Http\Request;

use BeachTV\Http\Requests;
use BeachTV\Models\Event;

class EventController extends Controller
{
    /**
     * Query all Events
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function query(Request $request)
    {
		return (new Event)->queryRecord($request);
    }
    
    /**
     * Create a new Event
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return (new Event)->createRecord($request, function(&$request, &$insertOverwrite) {
            $insertOverwrite['price'] = intval(strval($request->input('event.price')*100));
            $insertOverwrite['start_date'] = strtotime('+1 day', strtotime($request->input('event.start_date')));
            $insertOverwrite['end_date'] = ($request->input('event.end_date')) ? strtotime('+1 day', strtotime($request->input('event.end_date'))) : null;
            $insertOverwrite['rsvp_start'] = ($request->input('event.rsvp_start')) ? strtotime('+1 day', strtotime($request->input('event.rsvp_start'))) : null;
            $insertOverwrite['rsvp_until'] = ($request->input('event.rsvp_until')) ? strtotime('+1 day', strtotime($request->input('event.rsvp_until'))) : null;
            $insertOverwrite['repeat_until'] = ($request->input('event.repeat_until')) ? strtotime('+1 day', strtotime($request->input('event.repeat_until'))) : null;
        });
    }
    
    /**
     * Update the Event
     *
     * @param String $uuid
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        return (new Event)->updateRecord($request, function(&$request, &$updateOverwrite) {
            $updateOverwrite['price'] = intval(strval($request->input('event.price')*100));
            $updateOverwrite['start_date'] = strtotime('+1 day', strtotime($request->input('event.start_date')));
            $updateOverwrite['end_date'] = ($request->input('event.end_date')) ? strtotime('+1 day', strtotime($request->input('event.end_date'))) : null;
            $updateOverwrite['rsvp_start'] = ($request->input('event.rsvp_start')) ? strtotime('+1 day', strtotime($request->input('event.rsvp_start'))) : null;
            $updateOverwrite['rsvp_until'] = ($request->input('event.rsvp_until')) ? strtotime('+1 day', strtotime($request->input('event.rsvp_until'))) : null;
            $updateOverwrite['repeat_until'] = ($request->input('event.repeat_until')) ? strtotime('+1 day', strtotime($request->input('event.repeat_until'))) : null;
        });
    }

    /**
     * Find a new Event
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function retrieve($uuid)
    {
        return (new Event)->findRecord($uuid);
    }
    
    /**
     * Delete a record
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function delete($uuid) 
    {
        return (new Event)->deleteRecord($uuid);
    }
    
    /**
     * Options for Event requests
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function options() 
    {
        return response()->json([]);
    }
}
