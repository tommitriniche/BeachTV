<?php

namespace BeachTV\Http\Controllers;

use Illuminate\Http\Request;

use BeachTV\Http\Requests;
use BeachTV\Http\Controllers\Controller;
use BeachTV\Models\File;
use BeachTV\Helpers\API_Helper;
use Aws\S3\S3Client;

class FileController extends Controller
{
    /**
     * Query all files
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function query(Request $request)
    {
		return (new File)->queryRecord($request, [], function(&$request, &$options) {
		    if(isset($options['key_permalink'])) {
		        $deliveryItem = DeliveryItem::where('permalink', $request->input('key_permalink'))->first();
		        if($deliveryItem) {
		            $options['key_uuid'] = $deliveryItem->uuid;
		            unset($options['key_permalink']);
		        }
		    }
		});
    }
    
    /**
     * Create a new file
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        try {
            $file = File::create(array(
                'uploader_uuid' => $request->input('uploader_uuid'),
                'key_uuid' => $request->input('key_uuid'),
                'key' => $request->input('key'),
                'bucket' => $request->input('bucket'),
                'folder' => $request->input('folder'),
                'etag' => $request->input('etag'),
                'original_filename' => $request->input('name'),
                'type' => $request->input('type'),
            ));
            $file->generatePermalink($file->original_filename);
        } catch(\Illuminate\Database\QueryException $e) {
            return response()->make(API_Helper::parseSqlErrorToString($e->getMessage()), 400);
        }
        // get file type
		try {
            $s3 = S3Client::factory([
                'credentials' => [
                    'key' => config('services.aws.key'),    
                    'secret' => config('services.aws.secret')
                ],
                'region' => config('services.aws.region'),
                'version' => config('services.aws.version')
            ]);
			$obj = $s3->getObject(array(
			    'Bucket' => $request->input('bucket'),
			    'Key'    => $request->input('key')
			));
		} catch(Exception $e) {
			return response()->make($e->getMessage()); //json(['error' => $e->getMessage()]);
		}
		$file->content_type = $obj['ContentType'];
		// save the file
        if($file->save()) {
            return response()->json([
                'file' => $file
            ]);
        }
        return response()->make('Failed to create file.', 401);
    }
    
    /**
     * Update a record
     *
     * @param String $uuid
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        return (new File)->updateRecord($request);
    }
    
    
    /**
     * Get a event by either uuid or permalink
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function retrieve($uuid)
    {
        $file = File::where('uuid', $uuid)->first();
        
        if(!$file) {
            // try and ger by permalnk
            $file = File::where('permalink', $uuid)->first();
        }
        
        if(!$file) {
            return response()->make('File not found.', 400);
        }
        
        return response()->json([
            'file' => $file
        ]);
    }
    
    /**
     * Delete a event
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function delete($uuid) {
        $file = File::where('uuid', $uuid)->first();
        
        if(!$file) {
            // try to get by permalink
            $file = File::where('permalink', $uuid)->first();
        }
        
        if(!$file) {
            return response()->make('File not found.', 400);
        }
        // delete the event
        $file->delete();
        // done
        return response()->json([
            'file' => $file
        ]);
    }
    
    /**
     * Options for event requests
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function options() {
        return response()->json([]);
    }
}
