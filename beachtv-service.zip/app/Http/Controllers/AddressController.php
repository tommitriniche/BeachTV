<?php

namespace BeachTV\Http\Controllers;

use Illuminate\Http\Request;

use BeachTV\Http\Requests;
use BeachTV\Models\Address;

class AddressController extends Controller
{
    /**
     * Query all Addresss
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function query(Request $request)
    {
		return (new Address)->queryRecord($request);
    }
    
    /**
     * Create a new Address
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return (new Address)->createRecord($request);
    }
    
    /**
     * Update the Address
     *
     * @param String $uuid
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        return (new Address)->updateRecord($request);
    }

    /**
     * Find a new Address
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function retrieve($uuid)
    {
        return (new Address)->findRecord($uuid);
    }
    
    /**
     * Delete a record
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function delete($uuid) {
        return (new Address)->deleteRecord($uuid);
    }
    
    /**
     * Options for Address requests
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function options() {
        return response()->json([]);
    }
}
