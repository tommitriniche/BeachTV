<?php

namespace BeachTV\Http\Controllers;

use Illuminate\Http\Request;

use BeachTV\Http\Requests;
use BeachTV\Models\Video;
use BeachTV\Models\Category;
use BeachTV\Models\Tag;
use BeachTV\Models\VideoCategory;
use BeachTV\Helpers\API_Helper;
use Coconut_Job;

class VideoController extends Controller
{
    public function s3($path = '') {
        return 's3://' . config('services.aws.key') . ':' . config('services.aws.secret') . '@' . config('services.s3.bucket') . '/' . $path;
    }
    
    /**
     * Query all
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function mostViewed(Request $request)
    {
        $limit = $request->input('limit');
        if(!$limit) {
            $limit = 4;
        }
        if(isset($_REQUEST['category_uuid'])) {
            $all_videos = Video::where('category_uuid', $_REQUEST['category_uuid'])->get()->toArray();
        } else {
		    $all_videos = Video::all()->toArray();
        }
		usort($all_videos, function($a, $b) {
		    return $a['views_count'] < $b['views_count'];
		});
		return response()->json([
		   'videos' =>  array_slice($all_videos, 0, $limit)
	    ]);
    }
    
    /**
     * Query all
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function query(Request $request)
    {
        // if need to get the category is by slug
        if(!API_Helper::is_uuid($request->input('category_uuid'))) {
            // get the video uuid from slug
            $cat = Category::where('slug', $request->input('category_uuid'))->first();
            if($cat) {
                $_REQUEST['category_uuid'] = $cat->uuid;
            }
        }
        if($request->input('get_most_viewed') == 1) {
            return $this->mostViewed($request);
        }
		return (new Video)->queryRecord([$_REQUEST, $request]);
    }
    
    /**
     * Find a Video
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function retrieve($uuid)
    {
        return (new Video)->findRecord($uuid, ['category']);
    }
    
    /**
     * Create a new record
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return (new Video)->createRecord($request, function(&$request, &$insert) {
            $insert['encoding_complete'] = 0;
        }, function(&$request, &$record) {
            // lets send the video for encoding
            $path = pathinfo($record->path);
            // create encoding job
            $job = Coconut_Job::create([
                'api_key' => config('services.coconut.key'),
                'source' => $record->s3url,
                'webhook' => url('v1/videos/coconut?vid_id=' . $record->uuid),
                'metadata' => true,
                'outputs' => [
                    'mp4' => [$this->s3($path['dirname'] . '/' . $record->file->permalink . '/pvw/' . $record->uuid . '.mp4'), 'duration=15'],
                    'webm' => [$this->s3($path['dirname'] . '/' . $record->file->permalink . '/pvw/' . $record->uuid . '.web'), 'duration=15'],
                    'mp4' => $this->s3($path['dirname'] . '/' . $record->file->permalink . '/' . $record->uuid . '.mp4'),
                    'webm' => $this->s3($path['dirname'] . '/' . $record->file->permalink . '/' . $record->uuid . '.webm'),
                    'gif:300x' => $this->s3($path['dirname'] . '/' . $record->file->permalink . '/' . $record->uuid . '.gif'),
                    'jpg:300x' => $this->s3($path['dirname'] . '/' . $record->file->permalink . '/' . $record->uuid . '.jpg'),
                    'jpg:1280x' => $this->s3($path['dirname'] . '/' . $record->file->permalink . '/' . $record->uuid . '_poster.jpg'),
                ]
            ]);
            // update video info
            $record->title = basename($record->file->permalink);
            $record->slug = basename($record->file->permalink);
            // check on job status
            if($job->status == 'error') {
                $record->delete();
                return response()->json([
                    'error' => $job->message
                ], 400);
            }
        });
    }
    
    /**
     * Finished the coconut encoding job and updates the video record property
     * 
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function coconutWebHook(Request $request) 
    {
        $id = $request->input('vid_id');
        // get the video
        $video = Video::where('uuid', $id)->first();
        // get metadata
        $metadata = $request->input('metadata');
        // return response if video not found
        if(!$video) {
            return response()->make('Video record not found', 400);
        }
        // set encoding complete
        $video->meta = json_encode($metadata);
        $video->encoding_complete = 1;
        $video->save();
        // finish
        return response()->json([
            'video' => $video 
        ]);
    }
    
    /**
     * Update a record
     *
     * @param String $uuid
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        return (new Video)->updateRecord($request, function(&$request, &$overwrite, &$record) {
            $price = $request->input('video.price');
            if($price == null) {
                $price = 0;
            }
            $overwrite['price'] = preg_replace('/\D/', '', $price);
            $overwrite['meta'] = json_encode($record->meta);
            $overwrite['featured'] = ($request->input('video.featured')) ? 1 : 0;
            $tags = explode(',', $request->input('video.tagList'));
            foreach($tags as $tag) {
                if(trim($tag)) {
                    $tag = Tag::firstOrCreate([
                        'name' => trim($tag),
                        'element_id' => $record->uuid,
                        'element_type' => 'video',
                        'slug' => API_Helper::slugify(trim($tag))
                    ]);
                    if(!$tag->uuid) {
                        $tag->uuid = Tag::generateUuid();
                        $tag->save();
                    }
                }
            }
            // delete additional categories
            VideoCategory::where('video_uuid', $record->uuid)->delete();
        });
    }
    
    /**
     * Delete a record
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function delete($uuid) {
        return (new Video)->deleteRecord($uuid);
    }
    
    /**
     * Options for Tag requests
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function options() {
        return response()->json([]);
    }
}
