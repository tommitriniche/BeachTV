<?php

namespace BeachTV\Http\Controllers;

use Illuminate\Http\Request;

use BeachTV\Http\Requests;
use BeachTV\Models\User;
use BeachTV\Helpers\API_Helper;

class UserController extends Controller
{
    /**
     * Query all Users
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function query(Request $request)
    {
		return (new User)->queryRecord($request);
    }
    
    /**
     * Create a new User
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        return (new User)->createRecord($request, function(&$request, &$insert) {
            // make sure email is not duplicate
            $user_exist = User::where('email', $request->input('user.email'))->first();
            if($user_exist) {
                return response()->json([
                    'errors' => ['A user with this email address already exist.']
                ], 400);
            }
            $insert['username'] = strtolower($request->input('user.first_name') . '_' . $request->input('user.last_name') . '_' . API_Helper::hashid());
            $insert['email'] = strtolower($request->input('user.email'));
            $insert['password'] = bcrypt($request->input('user.password'));
            $insert['ip_address'] = $request->ip();
            $insert['last_login'] = time();
            $insert['date_of_birth'] = strtotime($request->input('user.date_of_birth'));
            // send welcome email
            API_Helper::send_email($insert['email'], 'Welcome to BeachTV!', view('emails/welcome')->render());
        });
    }
    
    /**
     * Update the User
     *
     * @param String $uuid
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        return (new User)->updateRecord($request);
    }

    /**
     * Find a new User
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function retrieve($uuid)
    {
        return (new User)->findRecord($uuid);
    }
    
    /**
     * Delete a record
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function delete($uuid) {
        return (new User)->deleteRecord($uuid);
    }
    
    /**
     * Options for User requests
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function options() {
        return response()->json([]);
    }
}
