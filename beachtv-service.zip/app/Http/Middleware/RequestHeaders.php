<?php

namespace BeachTV\Http\Middleware;

use Closure;
use App;

class RequestHeaders
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        // Allow methods
        header('Access-Control-Allow-Methods: GET, POST, PUT, OPTIONS, DELETE');
        header('Access-Control-Allow-Headers: Content-Type, Cache-Control, X-Requested-With');
        // Access control origin
        // local environment
        if(App::environment('local')) 
        {
            header('Access-Control-Allow-Origin: http://localhost:4200');
        } 
        // testing environment
        else if(App::environment('testing')) 
        {
            header('Access-Control-Allow-Origin: *');
        } 
        // production
        else if(App::environment('production')) 
        {
            // weird shit, this cleared on prod and don't know why 
            // -- probably the shit internet in singapore
            $http_origin = $request->headers->get('Origin');
            if(
                $http_origin == 'http://hq.beachtv.asia' || $http_origin == 'http://beachtv.asia' || $http_origin == 'http://www.beachtv.asia' || $http_origin == 'http://prod.beachtv.asia'
            ) {
                header('Access-Control-Allow-Origin: ' . $http_origin);   
            }
        }
        return $next($request);
    }
}
